//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CfOEBa6T.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/author",
			"/catalogue",
			"/home",
			"/login",
			"/profile",
			"/signup",
			"/book/$id",
			"/read/$id"
		],
		preloads: [
			"/assets/index-B0xBVIbZ.js",
			"/assets/jsx-runtime-DUAcabCT.js",
			"/assets/use-auth-Cjp6dS0l.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B0xBVIbZ.js"
		} }]
	},
	"/": {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Ck1iBOGd.js",
			"/assets/createLucideIcon-Z9UzC3tb.js",
			"/assets/book-open-CELdQBuh.js",
			"/assets/site-header-B0jvAp2A.js",
			"/assets/site-footer-BpQfWh5K.js"
		]
	},
	"/admin": {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DQ_b3oiO.js",
			"/assets/createLucideIcon-Z9UzC3tb.js",
			"/assets/book-open-CELdQBuh.js",
			"/assets/site-header-B0jvAp2A.js",
			"/assets/crown-CffUxYDp.js",
			"/assets/site-footer-BpQfWh5K.js",
			"/assets/clsx-CjueKrWZ.js"
		]
	},
	"/author": {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/author.tsx",
		children: void 0,
		preloads: [
			"/assets/author-DNCDnKim.js",
			"/assets/author-DqhPoakC.js",
			"/assets/author-vIiSvD8S.js",
			"/assets/site-header-B0jvAp2A.js",
			"/assets/site-footer-BpQfWh5K.js",
			"/assets/book-card-CV78ZZS_.js"
		]
	},
	"/catalogue": {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/catalogue.tsx",
		children: void 0,
		preloads: [
			"/assets/catalogue-Cjw9guFP.js",
			"/assets/site-header-B0jvAp2A.js",
			"/assets/site-footer-BpQfWh5K.js",
			"/assets/book-card-CV78ZZS_.js"
		]
	},
	"/home": {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/home.tsx",
		children: void 0,
		preloads: [
			"/assets/home-CtcgMPYV.js",
			"/assets/createLucideIcon-Z9UzC3tb.js",
			"/assets/book-open-CELdQBuh.js",
			"/assets/site-header-B0jvAp2A.js",
			"/assets/site-footer-BpQfWh5K.js",
			"/assets/book-card-CV78ZZS_.js"
		]
	},
	"/login": {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-Ce52ictN.js", "/assets/site-header-B0jvAp2A.js"]
	},
	"/profile": {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-nksuu9P9.js",
			"/assets/createLucideIcon-Z9UzC3tb.js",
			"/assets/circle-check-naYsKqS5.js",
			"/assets/book-open-CELdQBuh.js",
			"/assets/site-header-B0jvAp2A.js",
			"/assets/crown-CffUxYDp.js"
		]
	},
	"/signup": {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/signup.tsx",
		children: void 0,
		preloads: ["/assets/signup-BIpKmWUG.js", "/assets/site-header-B0jvAp2A.js"]
	},
	"/book/$id": {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/book.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/book._id-BO3e0EgZ.js",
			"/assets/createLucideIcon-Z9UzC3tb.js",
			"/assets/circle-check-naYsKqS5.js",
			"/assets/site-header-B0jvAp2A.js",
			"/assets/site-footer-BpQfWh5K.js",
			"/assets/book._id-Bn69RG1v.js",
			"/assets/book._id-mZOMi47Y.js"
		]
	},
	"/read/$id": {
		filePath: "/home/divine-ntambwe/Documents/Book App/LITN-Frontend/src/routes/read.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/read._id-BMgPmRRO.js",
			"/assets/createLucideIcon-Z9UzC3tb.js",
			"/assets/clsx-CjueKrWZ.js",
			"/assets/read._id-DqhPoakC.js",
			"/assets/read._id-K95XEtce.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
