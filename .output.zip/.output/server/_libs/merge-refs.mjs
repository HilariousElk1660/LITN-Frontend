//#region node_modules/merge-refs/dist/index.js
/**
* A function that merges React refs into one.
* Supports both functions and ref objects created using createRef() and useRef().
*
* Usage:
* ```tsx
* <div ref={mergeRefs(ref1, ref2, ref3)} />
* ```
*
* @param {(React.Ref<T> | undefined)[]} inputRefs Array of refs
* @returns {React.Ref<T> | React.RefCallback<T>} Merged refs
*/
function mergeRefs() {
	var inputRefs = [];
	for (var _i = 0; _i < arguments.length; _i++) inputRefs[_i] = arguments[_i];
	var filteredInputRefs = inputRefs.filter(Boolean);
	if (filteredInputRefs.length <= 1) return filteredInputRefs[0] || null;
	return function mergedRefs(ref) {
		for (var _i = 0, filteredInputRefs_1 = filteredInputRefs; _i < filteredInputRefs_1.length; _i++) {
			var inputRef = filteredInputRefs_1[_i];
			if (typeof inputRef === "function") inputRef(ref);
			else if (inputRef) inputRef.current = ref;
		}
	};
}
//#endregion
export { mergeRefs as t };
