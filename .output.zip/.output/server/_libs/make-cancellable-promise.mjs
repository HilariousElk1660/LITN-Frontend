//#region node_modules/make-cancellable-promise/dist/index.js
function makeCancellablePromise(promise) {
	let isCancelled = false;
	return {
		promise: new Promise((resolve, reject) => {
			promise.then((value) => !isCancelled && resolve(value)).catch((error) => !isCancelled && reject(error));
		}),
		cancel() {
			isCancelled = true;
		}
	};
}
//#endregion
export { makeCancellablePromise as t };
