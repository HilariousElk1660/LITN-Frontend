//#region node_modules/make-event-props/dist/index.js
var clipboardEvents = [
	"onCopy",
	"onCut",
	"onPaste"
];
var compositionEvents = [
	"onCompositionEnd",
	"onCompositionStart",
	"onCompositionUpdate"
];
var focusEvents = ["onFocus", "onBlur"];
var formEvents = [
	"onInput",
	"onInvalid",
	"onReset",
	"onSubmit"
];
var imageEvents = ["onLoad", "onError"];
var keyboardEvents = [
	"onKeyDown",
	"onKeyPress",
	"onKeyUp"
];
var mediaEvents = [
	"onAbort",
	"onCanPlay",
	"onCanPlayThrough",
	"onDurationChange",
	"onEmptied",
	"onEncrypted",
	"onEnded",
	"onError",
	"onLoadedData",
	"onLoadedMetadata",
	"onLoadStart",
	"onPause",
	"onPlay",
	"onPlaying",
	"onProgress",
	"onRateChange",
	"onSeeked",
	"onSeeking",
	"onStalled",
	"onSuspend",
	"onTimeUpdate",
	"onVolumeChange",
	"onWaiting"
];
var mouseEvents = [
	"onClick",
	"onContextMenu",
	"onDoubleClick",
	"onMouseDown",
	"onMouseEnter",
	"onMouseLeave",
	"onMouseMove",
	"onMouseOut",
	"onMouseOver",
	"onMouseUp"
];
var dragEvents = [
	"onDrag",
	"onDragEnd",
	"onDragEnter",
	"onDragExit",
	"onDragLeave",
	"onDragOver",
	"onDragStart",
	"onDrop"
];
var selectionEvents = ["onSelect"];
var touchEvents = [
	"onTouchCancel",
	"onTouchEnd",
	"onTouchMove",
	"onTouchStart"
];
var pointerEvents = [
	"onPointerDown",
	"onPointerMove",
	"onPointerUp",
	"onPointerCancel",
	"onGotPointerCapture",
	"onLostPointerCapture",
	"onPointerEnter",
	"onPointerLeave",
	"onPointerOver",
	"onPointerOut"
];
var uiEvents = ["onScroll"];
var wheelEvents = ["onWheel"];
var animationEvents = [
	"onAnimationStart",
	"onAnimationEnd",
	"onAnimationIteration"
];
var transitionEvents = ["onTransitionEnd"];
var otherEvents = ["onToggle"];
var changeEvents = ["onChange"];
var allEvents = [
	...clipboardEvents,
	...compositionEvents,
	...focusEvents,
	...formEvents,
	...imageEvents,
	...keyboardEvents,
	...mediaEvents,
	...mouseEvents,
	...dragEvents,
	...selectionEvents,
	...touchEvents,
	...pointerEvents,
	...uiEvents,
	...wheelEvents,
	...animationEvents,
	...transitionEvents,
	...changeEvents,
	...otherEvents
];
/**
* Returns an object with on-event callback props curried with provided args.
*
* @template ArgsType Type of arguments to curry on-event callbacks with.
* @param {PropsType} props Props passed to a component.
* @param {GetArgs<ArgsType>} [getArgs] A function that returns argument(s) on-event callbacks
*   shall be curried with.
*/
function makeEventProps(props, getArgs) {
	const eventProps = {};
	for (const eventName of allEvents) {
		const eventHandler = props[eventName];
		if (!eventHandler) continue;
		if (getArgs) eventProps[eventName] = ((event) => eventHandler(event, getArgs(eventName)));
		else eventProps[eventName] = eventHandler;
	}
	return eventProps;
}
//#endregion
export { makeEventProps as t };
