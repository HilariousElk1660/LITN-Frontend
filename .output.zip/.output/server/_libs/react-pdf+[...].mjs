import { r as __toESM, t as __commonJSMin } from "../_runtime.mjs";
import { n as require_react } from "./@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "./radix-ui__react-context+react.mjs";
import { t as clsx } from "./clsx.mjs";
import { a as getDocument, i as TextLayer$1, n as AnnotationMode, o as pdf_exports, t as AnnotationLayer$1 } from "./pdfjs-dist.mjs";
import { t as dequal } from "./dequal.mjs";
import { t as makeCancellablePromise } from "./make-cancellable-promise.mjs";
import { t as makeEventProps } from "./make-event-props.mjs";
import { t as mergeRefs } from "./merge-refs.mjs";
//#region node_modules/tiny-invariant/dist/esm/tiny-invariant.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var prefix = "Invariant failed";
function invariant(condition, message) {
	if (condition) return;
	throw new Error(prefix);
}
//#endregion
//#region node_modules/react-pdf/dist/DocumentContext.js
var import_warning = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Similar to invariant but only logs a warning if the condition is not met.
	* This can be used to log issues in development environments in critical
	* paths. Removing the logging code for production environments will keep the
	* same logic and follow the same code paths.
	*/
	var __DEV__ = false;
	var warning = function() {};
	if (__DEV__) {
		var printWarning = function printWarning(format, args) {
			var len = arguments.length;
			args = new Array(len > 1 ? len - 1 : 0);
			for (var key = 1; key < len; key++) args[key - 1] = arguments[key];
			var argIndex = 0;
			var message = "Warning: " + format.replace(/%s/g, function() {
				return args[argIndex++];
			});
			if (typeof console !== "undefined") console.error(message);
			try {
				throw new Error(message);
			} catch (x) {}
		};
		warning = function(condition, format, args) {
			var len = arguments.length;
			args = new Array(len > 2 ? len - 2 : 0);
			for (var key = 2; key < len; key++) args[key - 2] = arguments[key];
			if (format === void 0) throw new Error("`warning(condition, format, ...args)` requires a warning message argument");
			if (!condition) printWarning.apply(null, [format].concat(args));
		};
	}
	module.exports = warning;
})))(), 1);
var documentContext = (0, import_react.createContext)(null);
//#endregion
//#region node_modules/react-pdf/dist/LinkService.js
var DEFAULT_LINK_REL = "noopener noreferrer nofollow";
var LinkService = class {
	constructor() {
		this.externalLinkEnabled = true;
		this.externalLinkRel = void 0;
		this.externalLinkTarget = void 0;
		this.isInPresentationMode = false;
		this.pdfDocument = void 0;
		this.pdfViewer = void 0;
	}
	setDocument(pdfDocument) {
		this.pdfDocument = pdfDocument;
	}
	setViewer(pdfViewer) {
		this.pdfViewer = pdfViewer;
	}
	setExternalLinkRel(externalLinkRel) {
		this.externalLinkRel = externalLinkRel;
	}
	setExternalLinkTarget(externalLinkTarget) {
		this.externalLinkTarget = externalLinkTarget;
	}
	setHash() {}
	setHistory() {}
	get pagesCount() {
		return this.pdfDocument ? this.pdfDocument.numPages : 0;
	}
	get page() {
		invariant(this.pdfViewer, "PDF viewer is not initialized.");
		return this.pdfViewer.currentPageNumber || 0;
	}
	set page(value) {
		invariant(this.pdfViewer, "PDF viewer is not initialized.");
		this.pdfViewer.currentPageNumber = value;
	}
	get rotation() {
		return 0;
	}
	set rotation(_value) {}
	addLinkAttributes(link, url, newWindow) {
		link.href = url;
		link.rel = this.externalLinkRel || DEFAULT_LINK_REL;
		link.target = newWindow ? "_blank" : this.externalLinkTarget || "";
	}
	goToDestination(dest) {
		return new Promise((resolve) => {
			invariant(this.pdfDocument, "PDF document not loaded.");
			invariant(dest, "Destination is not specified.");
			if (typeof dest === "string") this.pdfDocument.getDestination(dest).then(resolve);
			else if (Array.isArray(dest)) resolve(dest);
			else dest.then(resolve);
		}).then((explicitDest) => {
			invariant(Array.isArray(explicitDest), `"${explicitDest}" is not a valid destination array.`);
			const destRef = explicitDest[0];
			new Promise((resolve) => {
				invariant(this.pdfDocument, "PDF document not loaded.");
				if (destRef instanceof Object) this.pdfDocument.getPageIndex(destRef).then((pageIndex) => {
					resolve(pageIndex);
				}).catch(() => {
					invariant(false, `"${destRef}" is not a valid page reference.`);
				});
				else if (typeof destRef === "number") resolve(destRef);
				else invariant(false, `"${destRef}" is not a valid destination reference.`);
			}).then((pageIndex) => {
				const pageNumber = pageIndex + 1;
				invariant(this.pdfViewer, "PDF viewer is not initialized.");
				invariant(pageNumber >= 1 && pageNumber <= this.pagesCount, `"${pageNumber}" is not a valid page number.`);
				this.pdfViewer.scrollPageIntoView({
					dest: explicitDest,
					pageIndex,
					pageNumber
				});
			});
		});
	}
	goToPage(pageNumber) {
		const pageIndex = pageNumber - 1;
		invariant(this.pdfViewer, "PDF viewer is not initialized.");
		invariant(pageNumber >= 1 && pageNumber <= this.pagesCount, `"${pageNumber}" is not a valid page number.`);
		this.pdfViewer.scrollPageIntoView({
			pageIndex,
			pageNumber
		});
	}
	goToXY() {}
	cachePageRef() {}
	getDestinationHash() {
		return "#";
	}
	getAnchorUrl() {
		return "#";
	}
	executeNamedAction() {}
	executeSetOCGState() {}
	isPageVisible() {
		return true;
	}
	isPageCached() {
		return true;
	}
	navigateTo(dest) {
		this.goToDestination(dest);
	}
};
//#endregion
//#region node_modules/react-pdf/dist/Message.js
function Message({ children, type }) {
	return (0, import_jsx_runtime.jsx)("div", {
		className: `react-pdf__message react-pdf__message--${type}`,
		children
	});
}
//#endregion
//#region node_modules/react-pdf/dist/PasswordResponses.js
var PasswordResponses = {
	NEED_PASSWORD: 1,
	INCORRECT_PASSWORD: 2
};
//#endregion
//#region node_modules/react-pdf/dist/shared/hooks/useResolver.js
function reducer(state, action) {
	switch (action.type) {
		case "RESOLVE": return {
			value: action.value,
			error: void 0
		};
		case "REJECT": return {
			value: false,
			error: action.error
		};
		case "RESET": return {
			value: void 0,
			error: void 0
		};
		default: return state;
	}
}
function useResolver() {
	return (0, import_react.useReducer)(reducer, {
		value: void 0,
		error: void 0
	});
}
//#endregion
//#region node_modules/react-pdf/dist/shared/utils.js
/**
* Checks if we're running in a browser environment.
*/
var isBrowser = typeof window !== "undefined";
/**
* Checks whether we're running from a local file system.
*/
var isLocalFileSystem = isBrowser && window.location.protocol === "file:";
/**
* Checks whether a variable is defined.
*
* @param {*} variable Variable to check
*/
function isDefined(variable) {
	return typeof variable !== "undefined";
}
/**
* Checks whether a variable is defined and not null.
*
* @param {*} variable Variable to check
*/
function isProvided(variable) {
	return isDefined(variable) && variable !== null;
}
/**
* Checks whether a variable provided is a string.
*
* @param {*} variable Variable to check
*/
function isString(variable) {
	return typeof variable === "string";
}
/**
* Checks whether a variable provided is an ArrayBuffer.
*
* @param {*} variable Variable to check
*/
function isArrayBuffer(variable) {
	return variable instanceof ArrayBuffer;
}
/**
* Checks whether a variable provided is a Blob.
*
* @param {*} variable Variable to check
*/
function isBlob(variable) {
	invariant(isBrowser, "isBlob can only be used in a browser environment");
	return variable instanceof Blob;
}
/**
* Checks whether a variable provided is a data URI.
*
* @param {*} variable String to check
*/
function isDataURI(variable) {
	return isString(variable) && /^data:/.test(variable);
}
function dataURItoByteString(dataURI) {
	invariant(isDataURI(dataURI), "Invalid data URI.");
	const [headersString = "", dataString = ""] = dataURI.split(",");
	if (headersString.split(";").indexOf("base64") !== -1) return atob(dataString);
	return unescape(dataString);
}
function getDevicePixelRatio() {
	return isBrowser && window.devicePixelRatio || 1;
}
var allowFileAccessFromFilesTip = "On Chromium based browsers, you can use --allow-file-access-from-files flag for debugging purposes.";
function displayCORSWarning() {
	(0, import_warning.default)(!isLocalFileSystem, `Loading PDF as base64 strings/URLs may not work on protocols other than HTTP/HTTPS. ${allowFileAccessFromFilesTip}`);
}
function cancelRunningTask(runningTask) {
	if (runningTask === null || runningTask === void 0 ? void 0 : runningTask.cancel) runningTask.cancel();
}
function makePageCallback(page, scale) {
	Object.defineProperty(page, "width", {
		get() {
			return this.getViewport({ scale }).width;
		},
		configurable: true
	});
	Object.defineProperty(page, "height", {
		get() {
			return this.getViewport({ scale }).height;
		},
		configurable: true
	});
	Object.defineProperty(page, "originalWidth", {
		get() {
			return this.getViewport({ scale: 1 }).width;
		},
		configurable: true
	});
	Object.defineProperty(page, "originalHeight", {
		get() {
			return this.getViewport({ scale: 1 }).height;
		},
		configurable: true
	});
	return page;
}
function isAbortException(error) {
	return error.name === "AbortException" || error.name === "RenderingCancelledException";
}
function loadFromFile(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => {
			if (!reader.result) return reject(/* @__PURE__ */ new Error("Error while reading a file."));
			resolve(reader.result);
		};
		reader.onerror = (event) => {
			if (!event.target) return reject(/* @__PURE__ */ new Error("Error while reading a file."));
			const { error } = event.target;
			if (!error) return reject(/* @__PURE__ */ new Error("Error while reading a file."));
			switch (error.code) {
				case error.NOT_FOUND_ERR: return reject(/* @__PURE__ */ new Error("Error while reading a file: File not found."));
				case error.SECURITY_ERR: return reject(/* @__PURE__ */ new Error("Error while reading a file: Security error."));
				case error.ABORT_ERR: return reject(/* @__PURE__ */ new Error("Error while reading a file: Aborted."));
				default: return reject(/* @__PURE__ */ new Error("Error while reading a file."));
			}
		};
		reader.readAsArrayBuffer(file);
	});
}
//#endregion
//#region node_modules/react-pdf/dist/Document.js
var { PDFDataRangeTransport } = pdf_exports;
var defaultOnPassword = (callback, reason) => {
	switch (reason) {
		case PasswordResponses.NEED_PASSWORD:
			callback(prompt("Enter the password to open this PDF file."));
			break;
		case PasswordResponses.INCORRECT_PASSWORD:
			callback(prompt("Invalid password. Please try again."));
			break;
		default:
	}
};
function isParameterObject(file) {
	return typeof file === "object" && file !== null && ("data" in file || "range" in file || "url" in file);
}
/**
* Loads a document passed using `file` prop.
*/
var Document = (0, import_react.forwardRef)(function Document({ children, className, error = "Failed to load PDF file.", externalLinkRel, externalLinkTarget, file, inputRef, imageResourcesPath, loading = "Loading PDF…", noData = "No PDF file specified.", onItemClick, onLoadError: onLoadErrorProps, onLoadProgress, onLoadSuccess: onLoadSuccessProps, onPassword = defaultOnPassword, onSourceError: onSourceErrorProps, onSourceSuccess: onSourceSuccessProps, options, renderMode, rotate, scale, ...otherProps }, ref) {
	const [sourceState, sourceDispatch] = useResolver();
	const { value: source, error: sourceError } = sourceState;
	const [pdfState, pdfDispatch] = useResolver();
	const { value: pdf, error: pdfError } = pdfState;
	const linkService = (0, import_react.useRef)(new LinkService());
	const pages = (0, import_react.useRef)([]);
	const prevFile = (0, import_react.useRef)(void 0);
	const prevOptions = (0, import_react.useRef)(void 0);
	if (file && file !== prevFile.current && isParameterObject(file)) {
		(0, import_warning.default)(!dequal(file, prevFile.current), `File prop passed to <Document /> changed, but it's equal to previous one. This might result in unnecessary reloads. Consider memoizing the value passed to "file" prop.`);
		prevFile.current = file;
	}
	if (options && options !== prevOptions.current) {
		(0, import_warning.default)(!dequal(options, prevOptions.current), `Options prop passed to <Document /> changed, but it's equal to previous one. This might result in unnecessary reloads. Consider memoizing the value passed to "options" prop.`);
		prevOptions.current = options;
	}
	const viewer = (0, import_react.useRef)({ scrollPageIntoView: (args) => {
		const { dest, pageNumber, pageIndex = pageNumber - 1 } = args;
		if (onItemClick) {
			onItemClick({
				dest,
				pageIndex,
				pageNumber
			});
			return;
		}
		const page = pages.current[pageIndex];
		if (page) {
			page.scrollIntoView();
			return;
		}
		(0, import_warning.default)(false, `An internal link leading to page ${pageNumber} was clicked, but neither <Document> was provided with onItemClick nor it was able to find the page within itself. Either provide onItemClick to <Document> and handle navigating by yourself or ensure that all pages are rendered within <Document>.`);
	} });
	(0, import_react.useImperativeHandle)(ref, () => ({
		linkService,
		pages,
		viewer
	}), []);
	/**
	* Called when a document source is resolved correctly
	*/
	function onSourceSuccess() {
		if (onSourceSuccessProps) onSourceSuccessProps();
	}
	/**
	* Called when a document source failed to be resolved correctly
	*/
	function onSourceError() {
		if (!sourceError) return;
		(0, import_warning.default)(false, sourceError.toString());
		if (onSourceErrorProps) onSourceErrorProps(sourceError);
	}
	function resetSource() {
		sourceDispatch({ type: "RESET" });
	}
	(0, import_react.useEffect)(resetSource, [file, sourceDispatch]);
	const findDocumentSource = (0, import_react.useCallback)(async () => {
		if (!file) return null;
		if (typeof file === "string") {
			if (isDataURI(file)) return { data: dataURItoByteString(file) };
			displayCORSWarning();
			return { url: file };
		}
		if (file instanceof PDFDataRangeTransport) return { range: file };
		if (isArrayBuffer(file)) return { data: file };
		/**
		* The cases below are browser-only.
		* If you're running on a non-browser environment, these cases will be of no use.
		*/
		if (isBrowser) {
			if (isBlob(file)) return { data: await loadFromFile(file) };
		}
		invariant(typeof file === "object", "Invalid parameter in file, need either Uint8Array, string or a parameter object");
		invariant(isParameterObject(file), "Invalid parameter object: need either .data, .range or .url");
		if ("url" in file && typeof file.url === "string") {
			if (isDataURI(file.url)) {
				const { url, ...otherParams } = file;
				return {
					data: dataURItoByteString(url),
					...otherParams
				};
			}
			displayCORSWarning();
		}
		return file;
	}, [file]);
	(0, import_react.useEffect)(() => {
		const cancellable = makeCancellablePromise(findDocumentSource());
		cancellable.promise.then((nextSource) => {
			sourceDispatch({
				type: "RESOLVE",
				value: nextSource
			});
		}).catch((error) => {
			sourceDispatch({
				type: "REJECT",
				error
			});
		});
		return () => {
			cancelRunningTask(cancellable);
		};
	}, [findDocumentSource, sourceDispatch]);
	(0, import_react.useEffect)(() => {
		if (typeof source === "undefined") return;
		if (source === false) {
			onSourceError();
			return;
		}
		onSourceSuccess();
	}, [source]);
	/**
	* Called when a document is read successfully
	*/
	function onLoadSuccess() {
		if (!pdf) return;
		if (onLoadSuccessProps) onLoadSuccessProps(pdf);
		pages.current = new Array(pdf.numPages);
		linkService.current.setDocument(pdf);
	}
	/**
	* Called when a document failed to read successfully
	*/
	function onLoadError() {
		if (!pdfError) return;
		(0, import_warning.default)(false, pdfError.toString());
		if (onLoadErrorProps) onLoadErrorProps(pdfError);
	}
	(0, import_react.useEffect)(function resetDocument() {
		pdfDispatch({ type: "RESET" });
	}, [pdfDispatch, source]);
	(0, import_react.useEffect)(function loadDocument() {
		if (!source) return;
		const destroyable = getDocument(options ? {
			...source,
			...options
		} : source);
		if (onLoadProgress) destroyable.onProgress = onLoadProgress;
		if (onPassword) destroyable.onPassword = onPassword;
		const loadingTask = destroyable;
		loadingTask.promise.then((nextPdf) => {
			if (loadingTask.destroyed) return;
			pdfDispatch({
				type: "RESOLVE",
				value: nextPdf
			});
		}).catch((error) => {
			if (loadingTask.destroyed) return;
			pdfDispatch({
				type: "REJECT",
				error
			});
		});
		return () => {
			loadingTask.destroy();
		};
	}, [
		options,
		pdfDispatch,
		source
	]);
	(0, import_react.useEffect)(() => {
		if (typeof pdf === "undefined") return;
		if (pdf === false) {
			onLoadError();
			return;
		}
		onLoadSuccess();
	}, [pdf]);
	(0, import_react.useEffect)(function setupLinkService() {
		linkService.current.setViewer(viewer.current);
		linkService.current.setExternalLinkRel(externalLinkRel);
		linkService.current.setExternalLinkTarget(externalLinkTarget);
	}, [externalLinkRel, externalLinkTarget]);
	const registerPage = (0, import_react.useCallback)((pageIndex, ref) => {
		pages.current[pageIndex] = ref;
	}, []);
	const unregisterPage = (0, import_react.useCallback)((pageIndex) => {
		delete pages.current[pageIndex];
	}, []);
	const childContext = (0, import_react.useMemo)(() => ({
		imageResourcesPath,
		linkService: linkService.current,
		onItemClick,
		pdf,
		registerPage,
		renderMode,
		rotate,
		scale,
		unregisterPage
	}), [
		imageResourcesPath,
		onItemClick,
		pdf,
		registerPage,
		renderMode,
		rotate,
		scale,
		unregisterPage
	]);
	const eventProps = (0, import_react.useMemo)(() => makeEventProps(otherProps, () => pdf), [otherProps, pdf]);
	function renderChildren() {
		function isFulfilledContext(context) {
			return Boolean(context === null || context === void 0 ? void 0 : context.pdf);
		}
		if (!isFulfilledContext(childContext)) throw new Error("pdf is undefined");
		const resolvedChildren = typeof children === "function" ? children(childContext) : children;
		return (0, import_jsx_runtime.jsx)(documentContext.Provider, {
			value: childContext,
			children: resolvedChildren
		});
	}
	function renderContent() {
		if (!file) return (0, import_jsx_runtime.jsx)(Message, {
			type: "no-data",
			children: typeof noData === "function" ? noData() : noData
		});
		if (pdf === void 0 || pdf === null) return (0, import_jsx_runtime.jsx)(Message, {
			type: "loading",
			children: typeof loading === "function" ? loading() : loading
		});
		if (pdf === false) return (0, import_jsx_runtime.jsx)(Message, {
			type: "error",
			children: typeof error === "function" ? error() : error
		});
		return renderChildren();
	}
	return (0, import_jsx_runtime.jsx)("div", {
		className: clsx("react-pdf__Document", className),
		ref: inputRef,
		...eventProps,
		children: renderContent()
	});
});
//#endregion
//#region node_modules/react-pdf/dist/shared/hooks/useDocumentContext.js
function useDocumentContext() {
	return (0, import_react.useContext)(documentContext);
}
//#endregion
//#region node_modules/react-pdf/dist/PageContext.js
var pageContext = (0, import_react.createContext)(null);
//#endregion
//#region node_modules/react-pdf/dist/shared/hooks/usePageContext.js
function usePageContext() {
	return (0, import_react.useContext)(pageContext);
}
//#endregion
//#region node_modules/react-pdf/dist/Page/AnnotationLayer.js
function AnnotationLayer() {
	const documentContext = useDocumentContext();
	const pageContext = usePageContext();
	invariant(pageContext, "Unable to find Page context.");
	const { filterAnnotations, imageResourcesPath, linkService, onGetAnnotationsError: onGetAnnotationsErrorProps, onGetAnnotationsSuccess: onGetAnnotationsSuccessProps, onRenderAnnotationLayerError: onRenderAnnotationLayerErrorProps, onRenderAnnotationLayerSuccess: onRenderAnnotationLayerSuccessProps, page, pdf, renderForms, rotate, scale = 1 } = {
		...documentContext,
		...pageContext
	};
	invariant(pdf, "Attempted to load page annotations, but no document was specified. Wrap <Page /> in a <Document /> or pass explicit `pdf` prop.");
	invariant(page, "Attempted to load page annotations, but no page was specified.");
	invariant(linkService, "Attempted to load page annotations, but no linkService was specified.");
	const [annotationsState, annotationsDispatch] = useResolver();
	const { value: annotations, error: annotationsError } = annotationsState;
	const layerElement = (0, import_react.useRef)(null);
	(0, import_warning.default)(Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--react-pdf-annotation-layer"), 10) === 1, "AnnotationLayer styles not found. Read more: https://github.com/wojtekmaj/react-pdf#support-for-annotations");
	function onLoadSuccess() {
		if (!annotations) return;
		if (onGetAnnotationsSuccessProps) onGetAnnotationsSuccessProps(annotations);
	}
	function onLoadError() {
		if (!annotationsError) return;
		(0, import_warning.default)(false, annotationsError.toString());
		if (onGetAnnotationsErrorProps) onGetAnnotationsErrorProps(annotationsError);
	}
	(0, import_react.useEffect)(function resetAnnotations() {
		annotationsDispatch({ type: "RESET" });
	}, [annotationsDispatch, page]);
	(0, import_react.useEffect)(function loadAnnotations() {
		if (!page) return;
		const cancellable = makeCancellablePromise(page.getAnnotations());
		const runningTask = cancellable;
		cancellable.promise.then((nextAnnotations) => {
			annotationsDispatch({
				type: "RESOLVE",
				value: nextAnnotations
			});
		}).catch((error) => {
			annotationsDispatch({
				type: "REJECT",
				error
			});
		});
		return () => {
			cancelRunningTask(runningTask);
		};
	}, [annotationsDispatch, page]);
	(0, import_react.useEffect)(() => {
		if (annotations === void 0) return;
		if (annotations === false) {
			onLoadError();
			return;
		}
		onLoadSuccess();
	}, [annotations]);
	function onRenderSuccess() {
		if (onRenderAnnotationLayerSuccessProps) onRenderAnnotationLayerSuccessProps();
	}
	function onRenderError(error) {
		(0, import_warning.default)(false, `${error}`);
		if (onRenderAnnotationLayerErrorProps) onRenderAnnotationLayerErrorProps(error);
	}
	const viewport = (0, import_react.useMemo)(() => page.getViewport({
		scale,
		rotation: rotate
	}), [
		page,
		rotate,
		scale
	]);
	(0, import_react.useEffect)(function renderAnnotationLayer() {
		if (!pdf || !page || !linkService || !annotations) return;
		const { current: layer } = layerElement;
		if (!layer) return;
		const clonedViewport = viewport.clone({ dontFlip: true });
		const annotationLayerParameters = {
			accessibilityManager: null,
			annotationCanvasMap: null,
			annotationEditorUIManager: null,
			annotationStorage: pdf.annotationStorage,
			commentManager: null,
			div: layer,
			l10n: null,
			linkService,
			page,
			structTreeLayer: null,
			viewport: clonedViewport
		};
		const renderParameters = {
			annotations: filterAnnotations ? filterAnnotations({ annotations }) : annotations,
			annotationStorage: pdf.annotationStorage,
			div: layer,
			imageResourcesPath,
			linkService,
			page,
			renderForms,
			viewport: clonedViewport
		};
		layer.innerHTML = "";
		try {
			new AnnotationLayer$1(annotationLayerParameters).render(renderParameters);
			onRenderSuccess();
		} catch (error) {
			onRenderError(error);
		}
		return () => {};
	}, [
		annotations,
		filterAnnotations,
		imageResourcesPath,
		linkService,
		page,
		pdf,
		renderForms,
		viewport
	]);
	return (0, import_jsx_runtime.jsx)("div", {
		className: clsx("react-pdf__Page__annotations", "annotationLayer"),
		ref: layerElement
	});
}
//#endregion
//#region node_modules/react-pdf/dist/shared/constants.js
var PDF_ROLE_TO_HTML_ROLE = {
	Document: null,
	DocumentFragment: null,
	Part: "group",
	Sect: "group",
	Div: "group",
	Aside: "note",
	NonStruct: "none",
	P: null,
	H: "heading",
	Title: null,
	FENote: "note",
	Sub: "group",
	Lbl: null,
	Span: null,
	Em: null,
	Strong: null,
	Link: "link",
	Annot: "note",
	Form: "form",
	Ruby: null,
	RB: null,
	RT: null,
	RP: null,
	Warichu: null,
	WT: null,
	WP: null,
	L: "list",
	LI: "listitem",
	LBody: null,
	Table: "table",
	TR: "row",
	TH: "columnheader",
	TD: "cell",
	THead: "columnheader",
	TBody: null,
	TFoot: null,
	Caption: null,
	Figure: "figure",
	Formula: null,
	Artifact: null
};
var HEADING_PATTERN = /^H(\d+)$/;
//#endregion
//#region node_modules/react-pdf/dist/shared/structTreeUtils.js
function isPdfRole(role) {
	return role in PDF_ROLE_TO_HTML_ROLE;
}
function isStructTreeNode(node) {
	return "children" in node;
}
function isStructTreeNodeWithOnlyContentChild(node) {
	if (!isStructTreeNode(node)) return false;
	return node.children.length === 1 && 0 in node.children && "id" in node.children[0];
}
function getRoleAttributes(node) {
	const attributes = {};
	if (isStructTreeNode(node)) {
		const { role } = node;
		const matches = role.match(HEADING_PATTERN);
		if (matches) {
			attributes.role = "heading";
			attributes["aria-level"] = Number(matches[1]);
		} else if (isPdfRole(role)) {
			const htmlRole = PDF_ROLE_TO_HTML_ROLE[role];
			if (htmlRole) attributes.role = htmlRole;
		}
	}
	return attributes;
}
function getBaseAttributes(node) {
	const attributes = {};
	if (isStructTreeNode(node)) {
		if (node.alt !== void 0) attributes["aria-label"] = node.alt;
		if (node.lang !== void 0) attributes.lang = node.lang;
		if (isStructTreeNodeWithOnlyContentChild(node)) {
			const [child] = node.children;
			if (child) {
				const childAttributes = getBaseAttributes(child);
				return {
					...attributes,
					...childAttributes
				};
			}
		}
	} else if ("id" in node) attributes["aria-owns"] = node.id;
	return attributes;
}
function getAttributes(node) {
	if (!node) return null;
	return {
		...getRoleAttributes(node),
		...getBaseAttributes(node)
	};
}
//#endregion
//#region node_modules/react-pdf/dist/StructTreeItem.js
function StructTreeItem({ className, node }) {
	const attributes = (0, import_react.useMemo)(() => getAttributes(node), [node]);
	const children = (0, import_react.useMemo)(() => {
		if (!isStructTreeNode(node)) return null;
		if (isStructTreeNodeWithOnlyContentChild(node)) return null;
		return node.children.map((child, index) => {
			return (0, import_jsx_runtime.jsx)(StructTreeItem, { node: child }, index);
		});
	}, [node]);
	return (0, import_jsx_runtime.jsx)("span", {
		className,
		...attributes,
		children
	});
}
//#endregion
//#region node_modules/react-pdf/dist/StructTree.js
function StructTree() {
	const pageContext = usePageContext();
	invariant(pageContext, "Unable to find Page context.");
	const { onGetStructTreeError: onGetStructTreeErrorProps, onGetStructTreeSuccess: onGetStructTreeSuccessProps } = pageContext;
	const [structTreeState, structTreeDispatch] = useResolver();
	const { value: structTree, error: structTreeError } = structTreeState;
	const { customTextRenderer, page } = pageContext;
	function onLoadSuccess() {
		if (!structTree) return;
		if (onGetStructTreeSuccessProps) onGetStructTreeSuccessProps(structTree);
	}
	function onLoadError() {
		if (!structTreeError) return;
		(0, import_warning.default)(false, structTreeError.toString());
		if (onGetStructTreeErrorProps) onGetStructTreeErrorProps(structTreeError);
	}
	(0, import_react.useEffect)(function resetStructTree() {
		structTreeDispatch({ type: "RESET" });
	}, [structTreeDispatch, page]);
	(0, import_react.useEffect)(function loadStructTree() {
		if (customTextRenderer) return;
		if (!page) return;
		const cancellable = makeCancellablePromise(page.getStructTree());
		const runningTask = cancellable;
		cancellable.promise.then((nextStructTree) => {
			structTreeDispatch({
				type: "RESOLVE",
				value: nextStructTree
			});
		}).catch((error) => {
			structTreeDispatch({
				type: "REJECT",
				error
			});
		});
		return () => cancelRunningTask(runningTask);
	}, [
		customTextRenderer,
		page,
		structTreeDispatch
	]);
	(0, import_react.useEffect)(() => {
		if (structTree === void 0) return;
		if (structTree === false) {
			onLoadError();
			return;
		}
		onLoadSuccess();
	}, [structTree]);
	if (!structTree) return null;
	return (0, import_jsx_runtime.jsx)(StructTreeItem, {
		className: "react-pdf__Page__structTree structTree",
		node: structTree
	});
}
//#endregion
//#region node_modules/react-pdf/dist/Page/Canvas.js
var ANNOTATION_MODE = AnnotationMode;
function Canvas(props) {
	const pageContext = usePageContext();
	invariant(pageContext, "Unable to find Page context.");
	const { _className, canvasBackground, devicePixelRatio = getDevicePixelRatio(), onRenderError: onRenderErrorProps, onRenderSuccess: onRenderSuccessProps, page, renderForms, renderTextLayer, pageColors, rotate, scale } = {
		...pageContext,
		...props
	};
	const { canvasRef } = props;
	invariant(page, "Attempted to render page canvas, but no page was specified.");
	const canvasElement = (0, import_react.useRef)(null);
	/**
	* Called when a page is rendered successfully.
	*/
	function onRenderSuccess() {
		if (!page) return;
		if (onRenderSuccessProps) onRenderSuccessProps(makePageCallback(page, scale));
	}
	/**
	* Called when a page fails to render.
	*/
	function onRenderError(error) {
		if (isAbortException(error)) return;
		(0, import_warning.default)(false, error.toString());
		if (onRenderErrorProps) onRenderErrorProps(error);
	}
	const renderViewport = (0, import_react.useMemo)(() => page.getViewport({
		scale: scale * devicePixelRatio,
		rotation: rotate
	}), [
		devicePixelRatio,
		page,
		rotate,
		scale
	]);
	const viewport = (0, import_react.useMemo)(() => page.getViewport({
		scale,
		rotation: rotate
	}), [
		page,
		rotate,
		scale
	]);
	(0, import_react.useEffect)(function drawPageOnCanvas() {
		if (!page) return;
		page.cleanup();
		const { current: canvas } = canvasElement;
		if (!canvas) return;
		canvas.width = renderViewport.width;
		canvas.height = renderViewport.height;
		canvas.style.width = `${Math.floor(viewport.width)}px`;
		canvas.style.height = `${Math.floor(viewport.height)}px`;
		canvas.style.visibility = "hidden";
		const renderContext = {
			annotationMode: renderForms ? ANNOTATION_MODE.ENABLE_FORMS : ANNOTATION_MODE.ENABLE,
			canvas,
			canvasContext: canvas.getContext("2d", { alpha: false }),
			pageColors,
			viewport: renderViewport
		};
		if (canvasBackground) renderContext.background = canvasBackground;
		const cancellable = page.render(renderContext);
		const runningTask = cancellable;
		cancellable.promise.then(() => {
			canvas.style.visibility = "";
			onRenderSuccess();
		}).catch(onRenderError);
		return () => cancelRunningTask(runningTask);
	}, [
		canvasBackground,
		page,
		pageColors,
		renderForms,
		renderViewport,
		viewport
	]);
	const cleanup = (0, import_react.useCallback)(() => {
		const { current: canvas } = canvasElement;
		/**
		* Zeroing the width and height cause most browsers to release graphics
		* resources immediately, which can greatly reduce memory consumption.
		*/
		if (canvas) {
			canvas.width = 0;
			canvas.height = 0;
		}
	}, []);
	(0, import_react.useEffect)(() => cleanup, [cleanup]);
	return (0, import_jsx_runtime.jsx)("canvas", {
		className: `${_className}__canvas`,
		dir: "ltr",
		ref: mergeRefs(canvasRef, canvasElement),
		style: {
			display: "block",
			userSelect: "none"
		},
		children: renderTextLayer ? (0, import_jsx_runtime.jsx)(StructTree, {}) : null
	});
}
//#endregion
//#region node_modules/react-pdf/dist/Page/TextLayer.js
function isTextItem(item) {
	return "str" in item;
}
var BLOCKED_CUSTOM_TEXT_TAGS = /* @__PURE__ */ new Set([
	"base",
	"embed",
	"iframe",
	"link",
	"meta",
	"object",
	"script",
	"style",
	"template"
]);
var URL_ATTRIBUTES = /* @__PURE__ */ new Set([
	"action",
	"formaction",
	"href",
	"poster",
	"src",
	"xlink:href"
]);
function isDangerousUrl(value) {
	let normalizedValue = "";
	for (const char of value) {
		const charCode = char.charCodeAt(0);
		if (charCode <= 32 || charCode === 127) continue;
		normalizedValue += char.toLowerCase();
	}
	return normalizedValue.startsWith("javascript:") || normalizedValue.startsWith("vbscript:");
}
function isElementNode(node) {
	return node.nodeType === Node.ELEMENT_NODE;
}
function isHtmlElement(node) {
	return isElementNode(node) && node instanceof HTMLElement;
}
function isBlockedCustomTextElement(node) {
	return isHtmlElement(node) && BLOCKED_CUSTOM_TEXT_TAGS.has(node.tagName.toLowerCase());
}
function sanitizeCustomHtmlElement(element) {
	const sanitizedElement = document.createElement(element.tagName.toLowerCase());
	Array.from(element.attributes).forEach((attribute) => {
		const attributeName = attribute.name.toLowerCase();
		if (attributeName.startsWith("on") || attributeName === "srcdoc") return;
		if (URL_ATTRIBUTES.has(attributeName) && isDangerousUrl(attribute.value)) return;
		sanitizedElement.setAttribute(attribute.name, attribute.value);
	});
	Array.from(element.childNodes).forEach((child) => {
		sanitizedElement.append(sanitizeCustomTextNode(child));
	});
	return sanitizedElement;
}
function sanitizeCustomTextNode(node) {
	var _a;
	if (isHtmlElement(node) && !isBlockedCustomTextElement(node)) return sanitizeCustomHtmlElement(node);
	return document.createTextNode((_a = node.textContent) !== null && _a !== void 0 ? _a : "");
}
function renderSafeCustomText(target, content) {
	const template = document.createElement("template");
	template.innerHTML = content;
	const sanitizedFragment = document.createDocumentFragment();
	Array.from(template.content.childNodes).forEach((child) => {
		sanitizedFragment.append(sanitizeCustomTextNode(child));
	});
	target.replaceChildren(sanitizedFragment);
}
function TextLayer() {
	const pageContext = usePageContext();
	invariant(pageContext, "Unable to find Page context.");
	const { customTextRenderer, onGetTextError, onGetTextSuccess, onRenderTextLayerError, onRenderTextLayerSuccess, page, pageIndex, pageNumber, rotate, scale } = pageContext;
	invariant(page, "Attempted to load page text content, but no page was specified.");
	const [textContentState, textContentDispatch] = useResolver();
	const { value: textContent, error: textContentError } = textContentState;
	const layerElement = (0, import_react.useRef)(null);
	(0, import_warning.default)(Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--react-pdf-text-layer"), 10) === 1, "TextLayer styles not found. Read more: https://github.com/wojtekmaj/react-pdf#support-for-text-layer");
	/**
	* Called when a page text content is read successfully
	*/
	function onLoadSuccess() {
		if (!textContent) return;
		if (onGetTextSuccess) onGetTextSuccess(textContent);
	}
	/**
	* Called when a page text content failed to read successfully
	*/
	function onLoadError() {
		if (!textContentError) return;
		(0, import_warning.default)(false, textContentError.toString());
		if (onGetTextError) onGetTextError(textContentError);
	}
	(0, import_react.useEffect)(function resetTextContent() {
		textContentDispatch({ type: "RESET" });
	}, [page, textContentDispatch]);
	(0, import_react.useEffect)(function loadTextContent() {
		if (!page) return;
		const cancellable = makeCancellablePromise(page.getTextContent());
		const runningTask = cancellable;
		cancellable.promise.then((nextTextContent) => {
			textContentDispatch({
				type: "RESOLVE",
				value: nextTextContent
			});
		}).catch((error) => {
			textContentDispatch({
				type: "REJECT",
				error
			});
		});
		return () => cancelRunningTask(runningTask);
	}, [page, textContentDispatch]);
	(0, import_react.useEffect)(() => {
		if (textContent === void 0) return;
		if (textContent === false) {
			onLoadError();
			return;
		}
		onLoadSuccess();
	}, [textContent]);
	/**
	* Called when a text layer is rendered successfully
	*/
	const onRenderSuccess = (0, import_react.useCallback)(() => {
		if (onRenderTextLayerSuccess) onRenderTextLayerSuccess();
	}, [onRenderTextLayerSuccess]);
	/**
	* Called when a text layer failed to render successfully
	*/
	const onRenderError = (0, import_react.useCallback)((error) => {
		if (isAbortException(error)) return;
		(0, import_warning.default)(false, error.toString());
		if (onRenderTextLayerError) onRenderTextLayerError(error);
	}, [onRenderTextLayerError]);
	function onMouseDown() {
		const layer = layerElement.current;
		if (!layer) return;
		layer.classList.add("selecting");
	}
	function onMouseUp() {
		const layer = layerElement.current;
		if (!layer) return;
		layer.classList.remove("selecting");
	}
	const viewport = (0, import_react.useMemo)(() => page.getViewport({
		scale,
		rotation: rotate
	}), [
		page,
		rotate,
		scale
	]);
	(0, import_react.useLayoutEffect)(function renderTextLayer() {
		if (!page || !textContent) return;
		const { current: layer } = layerElement;
		if (!layer) return;
		layer.innerHTML = "";
		const cancellable = new TextLayer$1({
			container: layer,
			textContentSource: page.streamTextContent({ includeMarkedContent: true }),
			viewport
		});
		const runningTask = cancellable;
		cancellable.render().then(() => {
			const end = document.createElement("div");
			end.className = "endOfContent";
			layer.append(end);
			const layerChildren = layer.querySelectorAll("[role=\"presentation\"]");
			if (customTextRenderer) {
				let index = 0;
				textContent.items.forEach((item, itemIndex) => {
					if (!isTextItem(item)) return;
					const child = layerChildren[index];
					if (!child) return;
					renderSafeCustomText(child, customTextRenderer({
						pageIndex,
						pageNumber,
						itemIndex,
						...item
					}));
					index += item.str && item.hasEOL ? 2 : 1;
				});
			}
			onRenderSuccess();
		}).catch(onRenderError);
		return () => cancelRunningTask(runningTask);
	}, [
		customTextRenderer,
		onRenderError,
		onRenderSuccess,
		page,
		pageIndex,
		pageNumber,
		textContent,
		viewport
	]);
	return (0, import_jsx_runtime.jsx)("div", {
		className: clsx("react-pdf__Page__textContent", "textLayer"),
		onMouseUp,
		onMouseDown,
		ref: layerElement
	});
}
//#endregion
//#region node_modules/react-pdf/dist/Page.js
var defaultScale = 1;
/**
* Displays a page.
*
* Should be placed inside `<Document />`. Alternatively, it can have `pdf` prop passed, which can be obtained from `<Document />`'s `onLoadSuccess` callback function, however some advanced functions like linking between pages inside a document may not be working correctly.
*/
function Page(props) {
	const { _className = "react-pdf__Page", _enableRegisterUnregisterPage = true, canvasBackground, canvasRef, children, className, customRenderer: CustomRenderer, customTextRenderer, devicePixelRatio, error = "Failed to load the page.", filterAnnotations, height, inputRef, loading = "Loading page…", noData = "No page specified.", onGetAnnotationsError: onGetAnnotationsErrorProps, onGetAnnotationsSuccess: onGetAnnotationsSuccessProps, onGetStructTreeError: onGetStructTreeErrorProps, onGetStructTreeSuccess: onGetStructTreeSuccessProps, onGetTextError: onGetTextErrorProps, onGetTextSuccess: onGetTextSuccessProps, onLoadError: onLoadErrorProps, onLoadSuccess: onLoadSuccessProps, onRenderAnnotationLayerError: onRenderAnnotationLayerErrorProps, onRenderAnnotationLayerSuccess: onRenderAnnotationLayerSuccessProps, onRenderError: onRenderErrorProps, onRenderSuccess: onRenderSuccessProps, onRenderTextLayerError: onRenderTextLayerErrorProps, onRenderTextLayerSuccess: onRenderTextLayerSuccessProps, pageColors, pageIndex: pageIndexProps, pageNumber: pageNumberProps, pdf, registerPage, renderAnnotationLayer: renderAnnotationLayerProps = true, renderForms = false, renderMode = "canvas", renderTextLayer: renderTextLayerProps = true, rotate: rotateProps, scale: scaleProps = defaultScale, unregisterPage, width, ...otherProps } = {
		...useDocumentContext(),
		...props
	};
	const [pageState, pageDispatch] = useResolver();
	const { value: page, error: pageError } = pageState;
	const pageElement = (0, import_react.useRef)(null);
	invariant(pdf, "Attempted to load a page, but no document was specified. Wrap <Page /> in a <Document /> or pass explicit `pdf` prop.");
	const pageIndex = isProvided(pageNumberProps) ? pageNumberProps - 1 : pageIndexProps !== null && pageIndexProps !== void 0 ? pageIndexProps : null;
	const pageNumber = pageNumberProps !== null && pageNumberProps !== void 0 ? pageNumberProps : isProvided(pageIndexProps) ? pageIndexProps + 1 : null;
	const rotate = rotateProps !== null && rotateProps !== void 0 ? rotateProps : page ? page.rotate : null;
	const scale = (0, import_react.useMemo)(() => {
		if (!page) return null;
		let pageScale = 1;
		const scaleWithDefault = scaleProps !== null && scaleProps !== void 0 ? scaleProps : defaultScale;
		if (width || height) {
			const viewport = page.getViewport({
				scale: 1,
				rotation: rotate
			});
			if (width) pageScale = width / viewport.width;
			else if (height) pageScale = height / viewport.height;
		}
		return scaleWithDefault * pageScale;
	}, [
		height,
		page,
		rotate,
		scaleProps,
		width
	]);
	(0, import_react.useEffect)(function hook() {
		return () => {
			if (!isProvided(pageIndex)) return;
			if (_enableRegisterUnregisterPage && unregisterPage) unregisterPage(pageIndex);
		};
	}, [
		_enableRegisterUnregisterPage,
		pdf,
		pageIndex,
		unregisterPage
	]);
	/**
	* Called when a page is loaded successfully
	*/
	function onLoadSuccess() {
		if (onLoadSuccessProps) {
			if (!page || !scale) return;
			onLoadSuccessProps(makePageCallback(page, scale));
		}
		if (_enableRegisterUnregisterPage && registerPage) {
			if (!isProvided(pageIndex) || !pageElement.current) return;
			registerPage(pageIndex, pageElement.current);
		}
	}
	/**
	* Called when a page failed to load
	*/
	function onLoadError() {
		if (!pageError) return;
		(0, import_warning.default)(false, pageError.toString());
		if (onLoadErrorProps) onLoadErrorProps(pageError);
	}
	(0, import_react.useEffect)(function resetPage() {
		pageDispatch({ type: "RESET" });
	}, [
		pageDispatch,
		pdf,
		pageIndex
	]);
	(0, import_react.useEffect)(function loadPage() {
		if (!pdf || !pageNumber) return;
		const cancellable = makeCancellablePromise(pdf.getPage(pageNumber));
		const runningTask = cancellable;
		cancellable.promise.then((nextPage) => {
			pageDispatch({
				type: "RESOLVE",
				value: nextPage
			});
		}).catch((error) => {
			pageDispatch({
				type: "REJECT",
				error
			});
		});
		return () => cancelRunningTask(runningTask);
	}, [
		pageDispatch,
		pdf,
		pageNumber
	]);
	(0, import_react.useEffect)(() => {
		if (page === void 0) return;
		if (page === false) {
			onLoadError();
			return;
		}
		onLoadSuccess();
	}, [page, scale]);
	const childContext = (0, import_react.useMemo)(() => isProvided(pageIndex) && pageNumber && isProvided(rotate) && isProvided(scale) ? {
		_className,
		canvasBackground,
		customTextRenderer,
		devicePixelRatio,
		filterAnnotations,
		onGetAnnotationsError: onGetAnnotationsErrorProps,
		onGetAnnotationsSuccess: onGetAnnotationsSuccessProps,
		onGetStructTreeError: onGetStructTreeErrorProps,
		onGetStructTreeSuccess: onGetStructTreeSuccessProps,
		onGetTextError: onGetTextErrorProps,
		onGetTextSuccess: onGetTextSuccessProps,
		onRenderAnnotationLayerError: onRenderAnnotationLayerErrorProps,
		onRenderAnnotationLayerSuccess: onRenderAnnotationLayerSuccessProps,
		onRenderError: onRenderErrorProps,
		onRenderSuccess: onRenderSuccessProps,
		onRenderTextLayerError: onRenderTextLayerErrorProps,
		onRenderTextLayerSuccess: onRenderTextLayerSuccessProps,
		page,
		pageColors,
		pageIndex,
		pageNumber,
		renderForms,
		renderTextLayer: renderTextLayerProps,
		rotate,
		scale
	} : null, [
		_className,
		canvasBackground,
		customTextRenderer,
		devicePixelRatio,
		filterAnnotations,
		onGetAnnotationsErrorProps,
		onGetAnnotationsSuccessProps,
		onGetStructTreeErrorProps,
		onGetStructTreeSuccessProps,
		onGetTextErrorProps,
		onGetTextSuccessProps,
		onRenderAnnotationLayerErrorProps,
		onRenderAnnotationLayerSuccessProps,
		onRenderErrorProps,
		onRenderSuccessProps,
		onRenderTextLayerErrorProps,
		onRenderTextLayerSuccessProps,
		page,
		pageColors,
		pageIndex,
		pageNumber,
		renderForms,
		renderTextLayerProps,
		rotate,
		scale
	]);
	const eventProps = (0, import_react.useMemo)(() => makeEventProps(otherProps, () => page ? scale ? makePageCallback(page, scale) : void 0 : page), [
		otherProps,
		page,
		scale
	]);
	const pageKey = `${pageIndex}@${scale}/${rotate}`;
	function renderMainLayer() {
		switch (renderMode) {
			case "custom":
				invariant(CustomRenderer, `renderMode was set to "custom", but no customRenderer was passed.`);
				return (0, import_jsx_runtime.jsx)(CustomRenderer, {}, `${pageKey}_custom`);
			case "none": return null;
			default: return (0, import_jsx_runtime.jsx)(Canvas, { canvasRef }, `${pageKey}_canvas`);
		}
	}
	function renderTextLayer() {
		if (!renderTextLayerProps) return null;
		return (0, import_jsx_runtime.jsx)(TextLayer, {}, `${pageKey}_text`);
	}
	function renderAnnotationLayer() {
		if (!renderAnnotationLayerProps) return null;
		return (0, import_jsx_runtime.jsx)(AnnotationLayer, {}, `${pageKey}_annotations`);
	}
	function renderChildren() {
		function isFulfilledContext(context) {
			return Boolean(context === null || context === void 0 ? void 0 : context.page);
		}
		if (!isFulfilledContext(childContext)) throw new Error("page is undefined");
		const resolvedChildren = typeof children === "function" ? children(childContext) : children;
		return (0, import_jsx_runtime.jsxs)(pageContext.Provider, {
			value: childContext,
			children: [
				renderMainLayer(),
				renderTextLayer(),
				renderAnnotationLayer(),
				resolvedChildren
			]
		});
	}
	function renderContent() {
		if (!pageNumber) return (0, import_jsx_runtime.jsx)(Message, {
			type: "no-data",
			children: typeof noData === "function" ? noData() : noData
		});
		if (pdf === null || page === void 0 || page === null) return (0, import_jsx_runtime.jsx)(Message, {
			type: "loading",
			children: typeof loading === "function" ? loading() : loading
		});
		if (pdf === false || page === false) return (0, import_jsx_runtime.jsx)(Message, {
			type: "error",
			children: typeof error === "function" ? error() : error
		});
		return renderChildren();
	}
	return (0, import_jsx_runtime.jsx)("div", {
		className: clsx(_className, className),
		"data-page-number": pageNumber,
		ref: mergeRefs(inputRef, pageElement),
		style: {
			"--scale-round-x": "1px",
			"--scale-round-y": "1px",
			"--scale-factor": "1",
			"--user-unit": `${scale}`,
			"--total-scale-factor": "calc(var(--scale-factor) * var(--user-unit))",
			backgroundColor: canvasBackground || "white",
			position: "relative",
			minWidth: "min-content",
			minHeight: "min-content"
		},
		...eventProps,
		children: renderContent()
	});
}
//#endregion
export { Document as n, Page as t };
