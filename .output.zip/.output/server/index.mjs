globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/admin-DQ_b3oiO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a966-Kmo20sSP+rbBvoFgHvejAwHiNWM\"",
		"mtime": "2026-08-17T07:40:40.245Z",
		"size": 108902,
		"path": "../public/assets/admin-DQ_b3oiO.js"
	},
	"/assets/author-DNCDnKim.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d-+22NAJOF8Fo4fT6MaYT0m2v4X1Y\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 157,
		"path": "../public/assets/author-DNCDnKim.js"
	},
	"/assets/author-DqhPoakC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"94-8i3vEw6sXbt5s5PjRnVJFtukmA4\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 148,
		"path": "../public/assets/author-DqhPoakC.js"
	},
	"/assets/author-vIiSvD8S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"644-X4IFFrg1FVGSnsOUimpSlpsv6eg\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 1604,
		"path": "../public/assets/author-vIiSvD8S.js"
	},
	"/assets/book-card-CV78ZZS_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f7-4TGgp2iC65u7oIMeUUJoZn9v498\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 1271,
		"path": "../public/assets/book-card-CV78ZZS_.js"
	},
	"/assets/book-open-CELdQBuh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"117-BBkRi/BDTbIgC1F1PAkrI4+Hzzs\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 279,
		"path": "../public/assets/book-open-CELdQBuh.js"
	},
	"/assets/book._id-BO3e0EgZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2afa-93MOhPVVDJq+z5MXuGjBWa3BXic\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 11002,
		"path": "../public/assets/book._id-BO3e0EgZ.js"
	},
	"/assets/book._id-Bn69RG1v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"150-iKW6fI6wifq9msG1/HC3eVQUHJI\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 336,
		"path": "../public/assets/book._id-Bn69RG1v.js"
	},
	"/assets/book._id-mZOMi47Y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21a-YFGvEKLr/kDmm5JEZCuUnu3arC4\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 538,
		"path": "../public/assets/book._id-mZOMi47Y.js"
	},
	"/assets/catalogue-Cjw9guFP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"126e-iaSKV37KbAvIc8Yb3je20o4mjAU\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 4718,
		"path": "../public/assets/catalogue-Cjw9guFP.js"
	},
	"/assets/circle-check-naYsKqS5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-sOsZnVWEDg+RG4dVOVcmSuobPNQ\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 178,
		"path": "../public/assets/circle-check-naYsKqS5.js"
	},
	"/assets/clsx-CjueKrWZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"170-hIN6XMVOMUzluNGmYPaM/SbauwQ\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 368,
		"path": "../public/assets/clsx-CjueKrWZ.js"
	},
	"/assets/cover-1-BYEYQnLR.jpg": {
		"type": "image/jpeg",
		"etag": "\"5799-37kxKONbVzfdXFCvktt/OOI5t/Q\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 22425,
		"path": "../public/assets/cover-1-BYEYQnLR.jpg"
	},
	"/assets/cover-2-nUm4dB_G.jpg": {
		"type": "image/jpeg",
		"etag": "\"5ca6-wcBPsxEfc0i5WcjCr0nVaRUaCkA\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 23718,
		"path": "../public/assets/cover-2-nUm4dB_G.jpg"
	},
	"/assets/cover-3-DZJm1cjc.jpg": {
		"type": "image/jpeg",
		"etag": "\"b602-e6+p2yx8HhjEgiVb85lGJOWbTJQ\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 46594,
		"path": "../public/assets/cover-3-DZJm1cjc.jpg"
	},
	"/assets/cover-4-DEFhf-UY.jpg": {
		"type": "image/jpeg",
		"etag": "\"3e13-CqwjBm6dN/svPyynM91vF+0qCN0\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 15891,
		"path": "../public/assets/cover-4-DEFhf-UY.jpg"
	},
	"/assets/cover-5-D0Y0D4Et.jpg": {
		"type": "image/jpeg",
		"etag": "\"7aba-9wCw/lT+glbvw2O9cpUU642oSk0\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 31418,
		"path": "../public/assets/cover-5-D0Y0D4Et.jpg"
	},
	"/assets/cover-6-BGDlK9El.jpg": {
		"type": "image/jpeg",
		"etag": "\"c131-wjkpkqiKnUGh3kMJXWdDdwe+TkA\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 49457,
		"path": "../public/assets/cover-6-BGDlK9El.jpg"
	},
	"/assets/createLucideIcon-Z9UzC3tb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4cf-K/PGu7VnHA/8X+w1tmg11ZM/eGA\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 1231,
		"path": "../public/assets/createLucideIcon-Z9UzC3tb.js"
	},
	"/assets/crown-CffUxYDp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16a-TNAKXHf0XOKC+KwPrGXx6J7nSMY\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 362,
		"path": "../public/assets/crown-CffUxYDp.js"
	},
	"/assets/favicon-DeOW818Z.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"9ca9-QmdK8D1HVHsSzLpsut/K/0JxHrc\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 40105,
		"path": "../public/assets/favicon-DeOW818Z.ico"
	},
	"/assets/home-CtcgMPYV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1dec-Jq4oudzxgKVogg9GoCDfRLdwCvE\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 7660,
		"path": "../public/assets/home-CtcgMPYV.js"
	},
	"/assets/jsx-runtime-DUAcabCT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"42a-6CWT3JsIzkgrrMo5qQ6L1UWEbvM\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 1066,
		"path": "../public/assets/jsx-runtime-DUAcabCT.js"
	},
	"/assets/login-Ce52ictN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"772-/mDtnXaa0I5yk/P4RMkZbxhV8FI\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 1906,
		"path": "../public/assets/login-Ce52ictN.js"
	},
	"/assets/index-B0xBVIbZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"873cc-n6oCbIK7DJP9t/yKF6pvTK61bvE\"",
		"mtime": "2026-08-17T07:40:40.245Z",
		"size": 553932,
		"path": "../public/assets/index-B0xBVIbZ.js"
	},
	"/assets/profile-nksuu9P9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ca3-/Gd+ZLhInLlhHS7pgOFKtBAUn+I\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 7331,
		"path": "../public/assets/profile-nksuu9P9.js"
	},
	"/assets/logo1-CwQrH5-r.png": {
		"type": "image/png",
		"etag": "\"35a9a-aV2APaiICufBKLM1SRgbx4Gv3iU\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 219802,
		"path": "../public/assets/logo1-CwQrH5-r.png"
	},
	"/assets/read._id-DqhPoakC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"94-8i3vEw6sXbt5s5PjRnVJFtukmA4\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 148,
		"path": "../public/assets/read._id-DqhPoakC.js"
	},
	"/assets/read._id-K95XEtce.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"96-RBKBCoyZz4Pf1AZqj0jAEfAoRvE\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 150,
		"path": "../public/assets/read._id-K95XEtce.js"
	},
	"/assets/routes-Ck1iBOGd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"102c-Tpd0RkDxCiEgImUpoSiEIk0Jgu4\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 4140,
		"path": "../public/assets/routes-Ck1iBOGd.js"
	},
	"/assets/read._id-BMgPmRRO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"68283-PxHQMtWEZQNypQ7qeW+q0Dne760\"",
		"mtime": "2026-08-17T07:40:40.246Z",
		"size": 426627,
		"path": "../public/assets/read._id-BMgPmRRO.js"
	},
	"/assets/signup-BIpKmWUG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"85b-mHVSRIQiDcJ86o19p5/M8vGfoQE\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 2139,
		"path": "../public/assets/signup-BIpKmWUG.js"
	},
	"/assets/site-footer-BpQfWh5K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"993-Lo507OjjFY6AYEjA4NQGqEOxMxc\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 2451,
		"path": "../public/assets/site-footer-BpQfWh5K.js"
	},
	"/assets/site-header-B0jvAp2A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c92-hKEXTNkUt6rlgp31VppFsorM2IU\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 7314,
		"path": "../public/assets/site-header-B0jvAp2A.js"
	},
	"/assets/styles-DTHkz-7Z.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16b7f-gH/mVxqvYIYtre4GFD1eYMgkXv8\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 93055,
		"path": "../public/assets/styles-DTHkz-7Z.css"
	},
	"/assets/use-auth-Cjp6dS0l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8c7b-3q0yA9ve1ZxyqAHfq5M5T6OT9mM\"",
		"mtime": "2026-08-17T07:40:40.247Z",
		"size": 35963,
		"path": "../public/assets/use-auth-Cjp6dS0l.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_tRTIpr = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_tRTIpr
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
