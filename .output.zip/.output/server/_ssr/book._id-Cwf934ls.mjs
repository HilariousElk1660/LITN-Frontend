import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book._id-Cwf934ls.js
var import_jsx_runtime = require_jsx_runtime();
var SplitErrorComponent = ({ reset }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "min-h-screen p-10 text-center",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Something went wrong." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick: reset,
		className: "mt-4 rounded-full bg-gradient-teal px-4 py-2 text-sm",
		children: "Retry"
	})]
});
//#endregion
export { SplitErrorComponent as errorComponent };
