import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as SiteHeader } from "./site-header-CgAShUuv.mjs";
import { t as SiteFooter } from "./site-footer-DlsoCshG.mjs";
import { t as Route } from "./author-DuBaVDf8.mjs";
import { t as BookCard } from "./book-card-80Ale8-j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/author-C-pDLavO.js
var import_jsx_runtime = require_jsx_runtime();
function AuthorPage() {
	const { author, works } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-4 pt-12 pb-16 sm:px-6 sm:pt-16 sm:pb-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-start gap-4 sm:flex-row sm:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-20 w-20 place-items-center rounded-full bg-gradient-teal font-display text-3xl text-primary-foreground sm:h-24 sm:w-24 sm:text-4xl",
							children: author.author.split(" ").map((n) => n[0]).join("")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl sm:text-4xl",
							children: author.author
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-muted-foreground",
							children: [
								"Author · ",
								works.length,
								" ",
								works.length === 1 ? "book" : "books",
								" on LITN"
							]
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-10 max-w-2xl text-lg leading-relaxed",
						children: [author.author, " writes from a small room with too many windows. Their work explores memory, place, and the slow weather of being a person. New chapters drop on LITN every Friday."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-14",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Published works"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
							children: works.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCard, { book: b }, b.id))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { AuthorPage as component };
