import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-auth-CIaruFYY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var supported_languages_default = {
	en: "english",
	fr: "french"
};
var BASE_URL = "http://localhost:8000";
function authHeaders() {
	const token = localStorage.getItem("access_token");
	return token ? { Authorization: `Bearer ${token}` } : {};
}
async function request(method, path, body) {
	const res = await fetch(`${BASE_URL}${path}`, {
		method,
		headers: {
			"Content-Type": "application/json",
			...authHeaders()
		},
		body: body !== void 0 ? JSON.stringify(body) : void 0
	});
	let data = null;
	try {
		data = await res.json();
	} catch {}
	if (!res.ok) throw new Error(data?.detail ?? `Request failed (${res.status})`);
	return data;
}
var api = {
	get(path) {
		return request("GET", path);
	},
	post(path, body) {
		return request("POST", path, body);
	},
	patch(path, body) {
		return request("PATCH", path, body);
	},
	delete(path) {
		return request("DELETE", path);
	},
	saveSession(auth) {
		localStorage.setItem("access_token", auth.access_token);
		localStorage.setItem("user", JSON.stringify({
			user_id: auth.user_id,
			email: auth.email,
			fullname: auth.fullname,
			role: auth.role
		}));
	},
	clearSession() {
		localStorage.removeItem("access_token");
		localStorage.removeItem("user");
	},
	getToken() {
		return localStorage.getItem("access_token");
	},
	getUser() {
		const raw = localStorage.getItem("user");
		const lang = supported_languages_default[navigator.language.slice(0, 2) || "en"];
		return raw ? {
			...JSON.parse(raw),
			"prefferedLanguage": lang
		} : null;
	}
};
var Ctx = (0, import_react.createContext)({
	user: null,
	role: null,
	isAdmin: false,
	isSuperAdmin: false,
	loading: true,
	signOut: () => {},
	refresh: () => {},
	backendUrl: ""
});
function AuthProvider({ children }) {
	const [user, setUser] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const backendUrl = "http://localhost:8000";
	const refresh = () => {
		setUser(api.getUser());
	};
	(0, import_react.useEffect)(() => {
		refresh();
		setLoading(false);
		const onStorage = (e) => {
			if (e.key === "access_token" || e.key === "user") refresh();
		};
		window.addEventListener("storage", onStorage);
		return () => window.removeEventListener("storage", onStorage);
	}, []);
	const signOut = () => {
		api.clearSession();
		setUser(null);
	};
	const role = user?.role ?? null;
	const isSuperAdmin = role === "super-admin";
	const isAdmin = role === "admin" || isSuperAdmin;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ctx.Provider, {
		value: {
			user,
			role,
			isAdmin,
			isSuperAdmin,
			loading,
			signOut,
			refresh,
			backendUrl
		},
		children
	});
}
var useAuth = () => (0, import_react.useContext)(Ctx);
//#endregion
export { useAuth as i, api as n, supported_languages_default as r, AuthProvider as t };
