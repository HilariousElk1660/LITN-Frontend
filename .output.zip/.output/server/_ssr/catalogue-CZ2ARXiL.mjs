import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalogue-CZ2ARXiL.js
var $$splitComponentImporter = () => import("./catalogue-DC_71Lkn.mjs");
var Route = createFileRoute("/catalogue")({
	validateSearch: (s) => ({ q: s.q ?? "" }),
	head: () => ({ meta: [{ title: "Library — LITN" }, {
		name: "description",
		content: "Browse the full LITN medical-training library — anatomy, pharmacology, emergency medicine, cardiology, surgery and internal medicine."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
