import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useAuth } from "./use-auth-CIaruFYY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as ArrowRight, S as Compass, k as BookOpen } from "../_libs/lucide-react.mjs";
import { t as SiteHeader } from "./site-header-CgAShUuv.mjs";
import { t as SiteFooter } from "./site-footer-DlsoCshG.mjs";
import { t as BookCard } from "./book-card-80Ale8-j.mjs";
import { n as useBooks } from "./use-books-B0GzInlS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/home-DhK8f_hm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const { user, loading, backendUrl } = useAuth();
	const { bookRequests, readersBooks } = useBooks();
	const [books, setBooks] = (0, import_react.useState)([]);
	const [loadingBooks, setLoadingBooks] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	console.log("YOUR BOOKS", readersBooks);
	(0, import_react.useEffect)(() => {
		const fetchBooks = async () => {
			setLoadingBooks(true);
			setError(null);
			try {
				const res = await fetch(`${backendUrl}/all_books`);
				if (!res.ok) throw new Error(`Failed to load books: ${res.status} ${res.statusText}`);
				setBooks((await res.json() ?? []).map((item) => ({
					id: item.book_id,
					title: item.book_name,
					author: item.author_name ?? "Unknown author",
					authorId: item.author_id ?? item.author_name?.toLowerCase().replace(/\s+/g, "-") ?? "unknown",
					cover: item.book_cover_url ?? "",
					genre: item.category ?? "Unknown",
					status: item.status === "Complete" ? "Complete" : "Serialised",
					chapters: item.chapters ?? item.pages ?? 0,
					rating: item.rating ?? 0,
					price: item.subscription_price ?? 0,
					currency: item.currency ?? "USD",
					synopsis: item.synopsis ?? item.description ?? ""
				})));
			} catch (err) {
				console.error(err);
				setError(err instanceof Error ? err.message : "Unable to load titles.");
			} finally {
				setLoadingBooks(false);
			}
		};
		fetchBooks();
	}, [backendUrl]);
	if (!loading && !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-xl px-4 py-20 text-center sm:px-6 sm:py-32",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl",
						children: "Access your dashboard"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted-foreground",
						children: "Please sign in to view your learning dashboard, reading progress, and registered titles."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "rounded-full bg-gradient-teal px-6 py-3 text-sm font-medium text-primary-foreground shadow-glow",
							children: "Sign in"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/signup",
							className: "rounded-full border border-border bg-surface px-6 py-3 text-sm font-medium text-foreground",
							children: "Create account"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
	bookRequests?.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:py-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative overflow-hidden rounded-3xl border border-border/60 bg-surface p-6 sm:p-8 lg:p-12 mb-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -z-10 bg-teal" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-20 -top-20 h-60 w-60 rounded-full bg-teal/10 blur-3xl" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col md:flex-row md:items-center md:justify-between gap-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "mt-4 font-display text-3xl sm:text-4xl lg:text-5xl",
									children: [
										"Welcome back, ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-gradient-teal",
											children: user?.fullname || "Colleague"
										}),
										"."
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted-foreground sm:text-base max-w-xl",
									children: "Track your active reading, explore high-yield clinical materials, and access your study resources all in one place."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/catalogue",
										className: "inline-flex items-center gap-2 rounded-full bg-gradient-teal px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-glow transition hover:opacity-90",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "h-4 w-4" }), " Browse Library"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/profile",
										className: "inline-flex items-center gap-2 rounded-full border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition hover:bg-surface",
										children: ["View Profile ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
									})]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center justify-between mb-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl sm:text-3xl",
								children: "Continue Reading..."
							}) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5",
							children: (readersBooks ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-full rounded-2xl border border-dashed border-border/60 p-8 text-center bg-surface/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: "You don't have any books in progress."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/catalogue",
									className: "mt-3 inline-flex items-center gap-1 text-sm font-semibold text-teal-bright hover:underline",
									children: ["Browse library ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
								})]
							}) : readersBooks.length ? readersBooks.slice(0, 5).map((b) => {
								const pct = b.percentage_completed ?? 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/read/$id",
									params: { id: b.book_id },
									className: "group block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative overflow-hidden rounded-xl border border-border/60 bg-surface shadow-card transition-transform duration-300 group-hover:-translate-y-1 group-hover:shadow-glow",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "aspect-[2/3] overflow-hidden",
											children: b.book_cover_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: b.book_cover_url,
												alt: b.book_name,
												loading: "lazy",
												className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex h-full w-full items-center justify-center bg-border/60",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "h-8 w-8 text-muted-foreground" })
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute right-3 top-3 rounded-full bg-background/80 px-2 py-1 text-[10px] font-semibold text-teal-bright backdrop-blur",
											children: [pct, "% completed"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 space-y-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "line-clamp-2 font-display text-base leading-tight font-medium",
												children: b.book_name
											}),
											b.author_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: b.author_name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 pt-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "h-1.5 w-full overflow-hidden rounded-full bg-border/60",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "h-full rounded-full bg-gradient-teal transition-all",
														style: { width: `${Math.min(100, Math.max(0, pct))}%` }
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-1 flex justify-between text-[10px] text-muted-foreground",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														"Page ",
														b.current_page,
														" of ",
														b.total_pages || "?"
													] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [pct, "%"] })]
												})]
											})
										]
									})]
								}, b.reader_book_id);
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "e" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl sm:text-3xl",
								children: "Featured Clinical Studies"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "Highly recommended anatomy, pharmacology, and clinical training titles."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/catalogue",
								className: "text-teal-bright hover:underline text-sm font-medium inline-flex items-center gap-1",
								children: ["View all ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
							})]
						}), loadingBooks ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-center text-muted-foreground py-10",
							children: "Loading books..."
						}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-center text-red-500 py-10",
							children: ["Error loading books: ", error]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5",
							children: books.slice(0, 5).map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCard, { book: b }, b.id))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Home as component };
