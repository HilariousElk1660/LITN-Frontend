import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useAuth, n as api, r as supported_languages_default } from "./use-auth-CIaruFYY.mjs";
import { P as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { C as Clock, D as ChevronDown, O as Check, _ as FileText, a as Upload, b as Crown, f as Pencil, g as ImagePlus, i as User, k as BookOpen, l as Shield, o as Trash2, r as X, s as Tag, v as Eye, y as Download } from "../_libs/lucide-react.mjs";
import { t as SiteHeader } from "./site-header-CgAShUuv.mjs";
import { t as SiteFooter } from "./site-footer-DlsoCshG.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-DHFwj5jh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RequireAdmin({ children }) {
	const { user, isAdmin, loading } = useAuth();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (loading) return;
		if (!user) navigate({ to: "/login" });
		else if (!isAdmin) navigate({ to: "/" });
	}, [
		user,
		isAdmin,
		loading,
		navigate
	]);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center text-muted-foreground",
		children: "Checking access…"
	});
	if (!user || !isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center text-muted-foreground",
		children: "Redirecting…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var REQUEST_TABS = [
	{
		key: "pending",
		label: "Pending",
		icon: Clock
	},
	{
		key: "paid",
		label: "Paid",
		icon: Check
	},
	{
		key: "declined",
		label: "Declined",
		icon: X
	}
];
var VIEWS = [
	{
		key: "books",
		label: "Uploaded books",
		icon: BookOpen
	},
	{
		key: "requests",
		label: "Book requests",
		icon: FileText
	},
	{
		key: "details",
		label: "Admin details",
		icon: User
	},
	{
		key: "super-admin",
		label: "Super Admin",
		icon: Crown
	}
];
function AdminDashboard() {
	const { user, isSuperAdmin, backendUrl } = useAuth();
	const token = api.getToken();
	const [view, setView] = (0, import_react.useState)("books");
	const [requestTab, setRequestTab] = (0, import_react.useState)("pending");
	const [requests, setRequests] = (0, import_react.useState)([]);
	const [books, setBooks] = (0, import_react.useState)([]);
	const [users, setUsers] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [loadingUsers, setLoadingUsers] = (0, import_react.useState)(false);
	const [promotingUserId, setPromotingUserId] = (0, import_react.useState)(null);
	const [promotingAction, setPromotingAction] = (0, import_react.useState)(null);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [declineModalOpen, setDeclineModalOpen] = (0, import_react.useState)(false);
	const [declineTarget, setDeclineTarget] = (0, import_react.useState)(null);
	const [declineReason, setDeclineReason] = (0, import_react.useState)("");
	const [declineSubmitting, setDeclineSubmitting] = (0, import_react.useState)(false);
	const [acceptModalOpen, setAcceptModalOpen] = (0, import_react.useState)(false);
	const [acceptTarget, setAcceptTarget] = (0, import_react.useState)(null);
	const [acceptSubmitting, setAcceptSubmitting] = (0, import_react.useState)(false);
	const [reportModalOpen, setReportModalOpen] = (0, import_react.useState)(false);
	const [reportLoading, setReportLoading] = (0, import_react.useState)(false);
	const [reportBook, setReportBook] = (0, import_react.useState)(null);
	const [bookReport, setBookReport] = (0, import_react.useState)(null);
	const [expandedCategories, setExpandedCategories] = (0, import_react.useState)({});
	const toggleCategory = (key) => {
		setExpandedCategories((prev) => ({
			...prev,
			[key]: !prev[key]
		}));
	};
	const [isAddAdminOpen, setIsAddAdminOpen] = (0, import_react.useState)(false);
	const [addAdminEmail, setAddAdminEmail] = (0, import_react.useState)("");
	const [addAdminRole, setAddAdminRole] = (0, import_react.useState)("admin");
	const [isSubmittingAddAdmin, setIsSubmittingAddAdmin] = (0, import_react.useState)(false);
	const [formState, setFormState] = (0, import_react.useState)({
		bookName: "",
		authorName: "",
		publishedDate: "",
		category: "",
		price: "",
		bookCover: null,
		pdfFile: null,
		currentTranslation: "english",
		translateTo: "french"
	});
	const loadBooks = async () => {
		if (!user) return;
		try {
			const res = await fetch(`${backendUrl}/admin_books?admin_id=${user?.user_id}`, { method: "GET" });
			const data = await res.json();
			if (!res.ok) throw new Error(data.error || "Failed to fetch uploaded books");
			setBooks(data ?? []);
		} catch (error) {
			console.error("Failed to load books", error);
			toast.error("Unable to load uploaded books.");
		}
	};
	const loadRequests = async () => {
		try {
			setLoading(true);
			const res = await fetch(`${backendUrl}/book_requests?admin_id=${user?.user_id}`, { method: "GET" });
			const data = await res.json();
			if (!res.ok) throw new Error(data.error || "Failed to fetch book requests");
			setRequests(data);
			setLoading(false);
		} catch (e) {
			console.error(`Error fetching book requests: ${e}`);
			setLoading(false);
		}
	};
	const loadAll = () => {
		loadRequests();
		loadBooks();
	};
	(0, import_react.useEffect)(() => {
		if (user) loadAll();
	}, [user]);
	(0, import_react.useEffect)(() => {
		if (user && isSuperAdmin) loadSuperAdminUsers();
	}, [
		user,
		isSuperAdmin,
		view
	]);
	(0, import_react.useEffect)(() => {
		if (!isSuperAdmin && view === "super-admin") setView("details");
	}, [isSuperAdmin, view]);
	const counts = (0, import_react.useMemo)(() => {
		return {
			pending: requests.filter((request) => request.status === "pending").length,
			paid: requests.filter((request) => request.status === "paid").length,
			declined: requests.filter((request) => request.status === "declined").length
		};
	}, [requests]);
	const bookStats = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const request of requests) {
			const bookId = request.book_id;
			const entry = map.get(bookId) ?? {
				totalRequests: 0,
				paidRequests: 0,
				declinedRequests: 0
			};
			entry.totalRequests += 1;
			if (request.status === "paid") entry.paidRequests += 1;
			if (request.status === "declined") entry.declinedRequests += 1;
			map.set(bookId, entry);
		}
		return map;
	}, [requests]);
	const updateRequestStatus = async (id, request_details, status, decline_reason) => {
		try {
			const token = api.getToken();
			setLoading(true);
			const payload = {
				request_id: request_details.request_id ?? request_details.id,
				status,
				book_id: request_details.book_id,
				reader_id: request_details.reader_id,
				reader_email: request_details.reader_email,
				reader_name: request_details.reader_name
			};
			if (decline_reason) payload.decline_reason = decline_reason;
			const res = await fetch(`${backendUrl}/update_book_request`, {
				method: "PUT",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${token}`
				},
				body: JSON.stringify(payload)
			});
			if (!res.ok) {
				const resData = await res.json().catch(() => null);
				throw new Error(resData?.detail || resData?.error || "Failed to update request");
			}
			toast.success(`Request ${status === "paid" ? "accepted" : "declined"}`);
			await loadRequests();
		} catch (error) {
			console.error("Error updating request status", error);
			toast.error("Unable to update request status.");
		} finally {
			setLoading(false);
		}
	};
	const openAcceptModal = (request) => {
		setAcceptTarget(request);
		setAcceptModalOpen(true);
	};
	const confirmAcceptRequest = async () => {
		if (!acceptTarget) return;
		setAcceptSubmitting(true);
		try {
			await updateRequestStatus(acceptTarget.request_id ?? acceptTarget.id ?? "", acceptTarget, "paid");
			setAcceptModalOpen(false);
			setAcceptTarget(null);
		} finally {
			setAcceptSubmitting(false);
		}
	};
	const openDeclineModal = (request) => {
		setDeclineTarget(request);
		setDeclineReason("");
		setDeclineModalOpen(true);
	};
	const confirmDeclineRequest = async () => {
		if (!declineTarget) return;
		if (!declineReason.trim()) {
			toast.error("Please enter a reason for declining this request.");
			return;
		}
		setDeclineSubmitting(true);
		try {
			await updateRequestStatus(declineTarget.request_id ?? declineTarget.id ?? "", declineTarget, "declined", declineReason.trim());
			setDeclineModalOpen(false);
			setDeclineTarget(null);
			setDeclineReason("");
		} finally {
			setDeclineSubmitting(false);
		}
	};
	const loadBookReport = async (book) => {
		setReportBook(book);
		setReportModalOpen(true);
		setReportLoading(true);
		setBookReport(null);
		setExpandedCategories({});
		try {
			const token = api.getToken();
			const res = await fetch(`${backendUrl}/admin_book_report?book_id=${book.book_id}`, {
				method: "GET",
				headers: { Authorization: `Bearer ${token}` }
			});
			const data = await res.json();
			if (!res.ok) throw new Error(data?.detail || data?.error || "Failed to load book report");
			setBookReport(data);
		} catch (error) {
			console.error("Error fetching book report", error);
			toast.error("Unable to fetch book report.");
		} finally {
			setReportLoading(false);
		}
	};
	const exportReportToXLSX = () => {
		if (!reportBook || !bookReport) return;
		const bookName = reportBook.book_name || "Book";
		const authorName = reportBook.author_name || "Unknown Author";
		const escapeXml = (str) => {
			if (!str) return "";
			return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
		};
		let readerRowsHtml = "";
		const appendReaders = (list, statusName) => {
			if (!list || list.length === 0) return;
			list.forEach((r) => {
				readerRowsHtml += `
      <Row>
        <Cell><Data ss:Type="String">${escapeXml(r.name)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXml(r.email)}</Data></Cell>
        <Cell><Data ss:Type="String">${statusName}</Data></Cell>
      </Row>`;
			});
		};
		appendReaders(bookReport.pendingList, "Pending Request");
		appendReaders(bookReport.acceptedList, "Request Accepted");
		appendReaders(bookReport.declinedList, "Request Declined");
		appendReaders(bookReport.completedList, "Completed Reading");
		appendReaders(bookReport.inProgressList, "Currently Reading");
		const categories = [
			{
				key: "pending",
				label: "Pending Requests",
				list: bookReport?.pendingList ?? []
			},
			{
				key: "accepted",
				label: "Accepted Requests",
				list: bookReport?.acceptedList ?? []
			},
			{
				key: "declined",
				label: "Declined Requests",
				list: bookReport?.declinedList ?? []
			},
			{
				key: "completed",
				label: "Readers Completed",
				list: bookReport?.completedList ?? []
			},
			{
				key: "inProgress",
				label: "Readers Currently Reading",
				list: bookReport?.inProgressList ?? []
			}
		];
		const maxRows = Math.max(...categories.map((cat) => cat.list.length), 0);
		const grandTotal = categories.reduce((acc, cat) => acc + cat.list.length, 0);
		const readerMatrixRowsXml = Array.from({ length: maxRows }).map((_, rowIndex) => {
			return `<Row>${categories.map((cat) => {
				const reader = cat.list[rowIndex];
				if (reader) return `<Cell><Data ss:Type="String">${escapeXml(reader.name ? `${reader.name} (${reader.email})` : reader.email)}</Data></Cell>`;
				return `<Cell><Data ss:Type="String">—</Data></Cell>`;
			}).join("")}</Row>`;
		}).join("\n      ");
		const xmlContent = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
  xmlns:o="urn:schemas-microsoft-com:office:office"
  xmlns:x="urn:schemas-microsoft-com:office:excel"
  xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
  <Styles>
    <Style ss:ID="Header">
      <Font ss:Bold="1" ss:Size="11" ss:Color="#FFFFFF"/>
      <Interior ss:Color="#14B8A6" ss:Pattern="Solid"/>
      <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
    </Style>
    <Style ss:ID="Subheader">
      <Font ss:Bold="1" ss:Size="10" ss:Color="#1F2937"/>
      <Interior ss:Color="#F3F4F6" ss:Pattern="Solid"/>
      <Alignment ss:Horizontal="Center"/>
    </Style>
    <Style ss:ID="Bold">
      <Font ss:Bold="1"/>
    </Style>
    <Style ss:ID="GrandTotal">
      <Font ss:Bold="1" ss:Size="11" ss:Color="#FFFFFF"/>
      <Interior ss:Color="#0F766E" ss:Pattern="Solid"/>
      <Alignment ss:Horizontal="Right" ss:Vertical="Center"/>
    </Style>
  </Styles>

  <Worksheet ss:Name="Book Report">
    <Table>
      <!-- Set column widths for 5 category columns -->
      <Column ss:Width="220"/>
      <Column ss:Width="220"/>
      <Column ss:Width="220"/>
      <Column ss:Width="220"/>
      <Column ss:Width="220"/>

      <!-- Book Summary Header -->
      <Row ss:StyleID="Header">
        <Cell ss:MergeAcross="4"><Data ss:Type="String">BOOK REPORT SUMMARY</Data></Cell>
      </Row>
      <Row>
        <Cell ss:StyleID="Bold"><Data ss:Type="String">Book Name:</Data></Cell>
        <Cell ss:MergeAcross="3"><Data ss:Type="String">${escapeXml(bookName)}</Data></Cell>
      </Row>
      <Row>
        <Cell ss:StyleID="Bold"><Data ss:Type="String">Author:</Data></Cell>
        <Cell ss:MergeAcross="3"><Data ss:Type="String">${escapeXml(authorName)}</Data></Cell>
      </Row>
      <Row></Row>

      <!-- Category Column Headings -->
      <Row ss:StyleID="Header">
        ${categories.map((cat) => `<Cell><Data ss:Type="String">${escapeXml(cat.label)}</Data></Cell>`).join("")}
      </Row>

      <!-- Category Reader Emails / Names Rows -->
      ${maxRows > 0 ? readerMatrixRowsXml : `
      <Row>
        <Cell ss:MergeAcross="4"><Data ss:Type="String">No readers in any category.</Data></Cell>
      </Row>`}

      <!-- Subtotal Per Category Row -->
      <Row ss:StyleID="Subheader">
        ${categories.map((cat) => `<Cell><Data ss:Type="String">Total: ${cat.list.length}</Data></Cell>`).join("")}
      </Row>

      <!-- Grand Total Row -->
      <Row ss:StyleID="GrandTotal">
        <Cell ss:MergeAcross="3"><Data ss:Type="String">Grand Total Readers:</Data></Cell>
        <Cell><Data ss:Type="Number">${grandTotal}</Data></Cell>
      </Row>
    </Table>
  </Worksheet>
</Workbook>`;
		const blob = new Blob([xmlContent], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		const sanitizedFileName = bookName.replace(/[^a-zA-Z0-9_-]/g, "_").toLowerCase();
		link.setAttribute("href", url);
		link.setAttribute("download", `${sanitizedFileName}_report.xlsx`);
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
		URL.revokeObjectURL(url);
		toast.success("Report exported to XLSX!");
	};
	const normalizeUsers = (value) => {
		value = value.filter((v) => v.email !== user?.email);
		if (Array.isArray(value)) return value;
		if (value && typeof value === "object") {
			const candidate = value;
			if (Array.isArray(candidate.users)) return candidate.users;
			if (Array.isArray(candidate.data)) return candidate.data;
		}
		return [];
	};
	const loadSuperAdminUsers = async () => {
		if (!isSuperAdmin) return;
		try {
			setLoadingUsers(true);
			setUsers(normalizeUsers(await (await fetch(`${backendUrl}/admins`, {
				method: "GET",
				headers: { Authorization: `Bearer ${token}` }
			})).json()));
		} catch (error) {
			console.error("Failed to load super admin users", error);
			toast.error("Unable to load users for Super Admin.");
			setUsers([]);
		} finally {
			setLoadingUsers(false);
		}
	};
	const promoteUserToRole = async (email, userId, role) => {
		if (!isSuperAdmin || !email) return;
		try {
			setPromotingUserId(userId);
			setPromotingAction(role);
			const res = await fetch(`${backendUrl}/change_role?email=${encodeURIComponent(email)}&role=${role}`, {
				method: "PATCH",
				headers: { Authorization: `Bearer ${token}` }
			});
			const data = await res.json();
			if (!res.ok) throw new Error(data.detail || data.error || "Failed to change role");
			toast.success(`Role updated to ${role}.`);
			await loadSuperAdminUsers();
		} catch (error) {
			console.error("Failed to promote user", error);
			toast.error(`Unable to update user role.`);
		} finally {
			setPromotingUserId(null);
			setPromotingAction(null);
		}
	};
	const handleAddAdmin = async (e) => {
		e.preventDefault();
		if (!addAdminEmail) {
			toast.error("Please enter an email address.");
			return;
		}
		setIsSubmittingAddAdmin(true);
		try {
			const res = await fetch(`${backendUrl}/change_role?email=${encodeURIComponent(addAdminEmail)}&role=${addAdminRole}`, {
				method: "PATCH",
				headers: { Authorization: `Bearer ${token}` }
			});
			const data = await res.json();
			if (!res.ok) throw new Error(data.detail || data.error || "Failed to change role");
			toast.success(`User role updated to ${addAdminRole}.`);
			setIsAddAdminOpen(false);
			setAddAdminEmail("");
			setAddAdminRole("admin");
			await loadSuperAdminUsers();
		} catch (error) {
			console.error("Failed to add admin user:", error);
			toast.error(error.message || "Failed to update user role.");
		} finally {
			setIsSubmittingAddAdmin(false);
		}
	};
	const handleDelete = async (bookId) => {
		try {
			setLoading(true);
			const res = await fetch(`${backendUrl}/delete_book/${bookId}`, { method: "DELETE" });
			if (!res.ok) {
				const payload = await res.json().catch(() => null);
				throw new Error(payload?.detail || payload?.error || "Failed to delete book");
			}
			toast.success("Book deleted");
			await loadBooks();
		} catch (error) {
			console.error("Error deleting book", error);
			toast.error("Unable to delete book.");
		} finally {
			setLoading(false);
		}
	};
	const handleSubmit = async (event) => {
		event.preventDefault();
		if (!user) return;
		if (!formState.pdfFile || formState.pdfFile.type !== "application/pdf") {
			toast.error("Book file must be a PDF.");
			return;
		}
		const formData = new FormData();
		formData.append("admin_id", user?.user_id);
		formData.append("uploaded_by", user.email ?? "");
		formData.append("author_name", formState.authorName);
		formData.append("book_name", formState.bookName);
		formData.append("category", formState.category);
		formData.append("published_date", formState.publishedDate);
		formData.append("price", formState.price);
		formData.append("book_division_type", "full");
		formData.append("pdf_file", formState.pdfFile);
		const fromLang = supported_languages_default[formState.currentTranslation] || "english";
		formData.append("translate_from", fromLang);
		formData.append("translate_to", formState.translateTo);
		try {
			setUploading(true);
			const res = await fetch(`${backendUrl}/create_book`, {
				method: "POST",
				body: formData
			});
			const data = await res.json();
			if (!res.ok) throw new Error(data.detail || data.error || "Failed to upload book");
			toast.success("Book upload started.");
			setFormState({
				bookName: "",
				authorName: "",
				publishedDate: "",
				category: "",
				price: "",
				bookCover: null,
				pdfFile: null,
				currentTranslation: "english",
				translateTo: "french"
			});
			await loadBooks();
		} catch (error) {
			console.error("Error uploading book", error);
			toast.error("Unable to upload book.");
		} finally {
			setUploading(false);
		}
	};
	const handleViewBook = (book) => {
		window.location.href = `/read/${book.book_id}`;
	};
	const selectedRequests = requests.filter((request) => request.status === requestTab);
	const isMobileView = window.matchMedia("(max-width: 768px)").matches;
	const TableForm = () => {
		const categories = [
			{
				key: "pending",
				label: "Pending Requests",
				list: bookReport?.pendingList ?? [],
				colorClass: "text-teal-600 bg-teal-500/10"
			},
			{
				key: "accepted",
				label: "Accepted Requests",
				list: bookReport?.acceptedList ?? [],
				colorClass: "text-teal-600 bg-teal-500/10"
			},
			{
				key: "declined",
				label: "Declined Requests",
				list: bookReport?.declinedList ?? [],
				colorClass: "text-destructive bg-destructive/10"
			},
			{
				key: "completed",
				label: "Readers Completed",
				list: bookReport?.completedList ?? [],
				colorClass: "text-teal-600 bg-teal-500/10"
			},
			{
				key: "inProgress",
				label: "Readers Currently Reading",
				list: bookReport?.inProgressList ?? [],
				colorClass: "text-teal-600 bg-teal-500/10"
			}
		];
		const maxRows = Math.max(...categories.map((c) => c.list.length), 0);
		categories.reduce((acc, cat) => acc + cat.list.length, 0);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-full overflow-x-auto rounded-xl border border-border/60 bg-background/50 backdrop-blur-sm p-2 text-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
					className: "border-b border-border/60 bg-muted/20",
					children: categories.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "p-3 font-semibold text-foreground min-w-[180px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cat.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `inline-flex items-center justify-center rounded-full px-2 py-0.5 text-xs font-bold ${cat.colorClass}`,
								children: cat.list.length
							})]
						})
					}, cat.key))
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
					className: "divide-y divide-border/20",
					children: maxRows === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: categories.length,
						className: "p-6 text-center text-xs text-muted-foreground",
						children: "No data available across any category."
					}) }) : Array.from({ length: maxRows }).map((_, rowIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
						className: "hover:bg-muted/10 transition-colors",
						children: categories.map((cat) => {
							const reader = cat.list[rowIndex];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3 align-top text-xs",
								children: reader ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col truncate",
									title: `${reader.name} (${reader.email})`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground truncate",
										children: reader.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground truncate",
										children: reader.email
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground/30",
									children: "—"
								})
							}, cat.key);
						})
					}, rowIndex))
				})]
			})
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen overflow-x-hidden bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 sm:py-12 min-w-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-4xl border border-border/60 bg-surface p-8 shadow-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-2xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "inline-flex items-center gap-2 rounded-full bg-teal-500/10 px-3 py-1 text-sm font-semibold text-teal-700",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-4 w-4" }), "Admin dashboard"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "mt-4 text-4xl font-semibold tracking-tight text-foreground",
										children: "Manage books, requests, and admin details"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 max-w-xl text-sm text-muted-foreground",
										children: "Upload new books, review subscriptions and purchase requests from readers, and keep your admin profile visible in one place."
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3 min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-3xl border border-border/70 bg-background p-5 min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
											children: "Books uploaded"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 text-3xl font-semibold",
											children: books.length
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-3xl border border-border/70 bg-background p-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
											children: "Open requests"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 text-3xl font-semibold",
											children: counts.pending
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-3xl border border-border/70 bg-background p-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
											children: "Paid requests"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 text-3xl font-semibold",
											children: counts.paid
										})]
									})
								]
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 lg:grid-cols-[240px_minmax(0,1fr)] min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "space-y-3 rounded-3xl border border-border/60 bg-surface p-4 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold uppercase tracking-[0.25em] text-muted-foreground",
								children: "Dashboard views"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2",
								children: VIEWS.map(({ key, label, icon: Icon }) => key === "super-admin" && !isSuperAdmin ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: `flex w-full items-center gap-3 rounded-3xl px-4 py-3 text-left text-sm font-medium transition ${view === key ? "border border-teal-400 bg-teal-500/10 text-foreground" : "text-muted-foreground hover:bg-surface"}`,
									onClick: () => setView(key),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }), label]
								}, key))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "space-y-8",
							children: [
								view === "books" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-3xl border border-border/60 bg-surface p-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-2xl font-semibold",
												children: "Upload a new book"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm text-muted-foreground",
												children: "Create a book record, upload cover art and PDF, and publish it for readers."
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "inline-flex items-center gap-2 rounded-full bg-teal-500/10 px-3 py-1 text-sm font-semibold text-teal-700",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }), "PDF upload only"]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
											className: "mt-6 grid gap-4 md:grid-cols-2",
											onSubmit: handleSubmit,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "grid gap-2 text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Book name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														value: formState.bookName,
														onChange: (event) => setFormState((prev) => ({
															...prev,
															bookName: event.target.value
														})),
														className: "rounded-2xl border border-border/60 bg-background px-4 py-3 text-sm text-foreground outline-none transition focus:border-teal-400",
														placeholder: "E.g. The Next Chapter",
														required: true
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "grid gap-2 text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Author name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														value: formState.authorName,
														onChange: (event) => setFormState((prev) => ({
															...prev,
															authorName: event.target.value
														})),
														className: "rounded-2xl border border-border/60 bg-background px-4 py-3 text-sm text-foreground outline-none transition focus:border-teal-400",
														placeholder: "E.g. Jane Doe",
														required: true
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "grid gap-2 text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Published date" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "date",
														value: formState.publishedDate,
														onChange: (event) => setFormState((prev) => ({
															...prev,
															publishedDate: event.target.value
														})),
														className: "rounded-2xl border border-border/60 bg-background px-4 py-3 text-sm text-foreground outline-none transition focus:border-teal-400",
														required: true
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "grid gap-2 text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														value: formState.category,
														onChange: (event) => setFormState((prev) => ({
															...prev,
															category: event.target.value
														})),
														className: "rounded-2xl border border-border/60 bg-background px-4 py-3 text-sm text-foreground outline-none transition focus:border-teal-400",
														placeholder: "E.g. Fiction",
														required: true
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "grid gap-2 text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Current translation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
														value: formState.currentTranslation,
														onChange: (event) => setFormState((prev) => ({
															...prev,
															currentTranslation: event.target.value
														})),
														className: "rounded-2xl border border-border/60 bg-background px-4 py-3 text-sm text-foreground outline-none transition focus:border-teal-400",
														children: Object.entries(supported_languages_default).map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value,
															children: value
														}, key))
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "grid gap-2 text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Translate book to" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
														value: formState.translateTo,
														onChange: (event) => setFormState((prev) => ({
															...prev,
															translateTo: event.target.value
														})),
														className: "rounded-2xl border border-border/60 bg-background px-4 py-3 text-sm text-foreground outline-none transition focus:border-teal-400",
														children: Object.entries(supported_languages_default).map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value,
															children: value
														}, key))
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "grid gap-2 text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Price" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "number",
														min: "0",
														step: "0.01",
														value: formState.price,
														onChange: (event) => setFormState((prev) => ({
															...prev,
															price: event.target.value
														})),
														className: "rounded-2xl border border-border/60 bg-background px-4 py-3 text-sm text-foreground outline-none transition focus:border-teal-400",
														placeholder: "e.g. 1000",
														required: true
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "grid gap-2 text-sm",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Upload book PDF" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															type: "file",
															accept: "application/pdf",
															onChange: (event) => setFormState((prev) => ({
																...prev,
																pdfFile: event.target.files?.[0] ?? null
															})),
															className: "file:rounded-full file:border-0 file:bg-teal-500 file:px-4 file:py-2 file:text-sm file:text-white",
															required: true
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs text-muted-foreground",
															children: "Only PDF files are accepted."
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "md:col-span-2 text-center",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "submit",
														disabled: uploading,
														className: "inline-flex items-center justify-center gap-2 rounded-3xl bg-teal-600 px-6 py-3 text-sm font-semibold text-white transition hover:bg-teal-700 disabled:cursor-not-allowed disabled:opacity-60",
														children: uploading ? "Uploading…" : "Create book"
													})
												})
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-center justify-between gap-4 rounded-3xl border border-border/60 bg-surface p-5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-xl font-semibold",
												children: "Uploaded books"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-muted-foreground",
												children: "Review the books you have added and their current performance."
											})] })
										}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "rounded-3xl border border-border/60 bg-background p-8 text-center text-muted-foreground",
											children: "Loading books…"
										}) : books.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "rounded-3xl border border-border/60 bg-background p-8 text-center text-muted-foreground",
											children: "No books uploaded yet."
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid gap-4 lg:grid-cols-1",
											children: books.map((book) => {
												bookStats.get(book.book_id);
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
													className: "overflow-hidden rounded-3xl border border-border/60 bg-surface shadow-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex gap-4 p-5 sm:items-center min-w-0",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "h-28 w-24 overflow-hidden rounded-3xl bg-muted flex-shrink-0",
															children: book.book_cover_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
																src: book.book_cover_url,
																alt: book.book_name,
																className: "h-full w-full object-cover"
															}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "flex h-full w-full items-center justify-center text-muted-foreground",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "h-8 w-8" })
															})
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex-1 min-w-0 space-y-2",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between min-w-0",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "min-w-0",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
																		className: "text-lg font-semibold truncate",
																		children: book.book_name
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-sm text-muted-foreground truncate",
																		children: book.author_name
																	})]
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "inline-flex items-center gap-2 rounded-full bg-background px-3 py-1 text-xs font-medium text-muted-foreground",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "h-3.5 w-3.5" }), book.category ?? "Uncategorized"]
																})]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "grid grid-cols-1 gap-3 text-sm text-muted-foreground sm:grid-cols-2 lg:grid-cols-2",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "rounded-3xl bg-background p-3",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs uppercase tracking-[0.18em]",
																		children: "Chapters"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "mt-2 text-base font-semibold",
																		children: book.chapters
																	})]
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "rounded-3xl bg-background p-3",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs uppercase tracking-[0.18em]",
																		children: "Price"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "mt-2 text-base font-semibold",
																		children: book.subscription_price ? `${book.subscription_price}` : "—"
																	})]
																})]
															})]
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex flex-wrap gap-2 border-t border-border/60 bg-background/70 p-4",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => handleViewBook(book),
																className: "inline-flex items-center gap-2 rounded-3xl border border-border px-4 py-2 text-sm text-foreground transition hover:border-teal-400 cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4" }), "View book"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => loadBookReport(book),
																className: "inline-flex items-center gap-2 rounded-3xl border border-border px-4 py-2 text-sm text-foreground transition hover:border-teal-400 cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4" }), "Generate report"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => toast.success("Edit book flow not yet implemented."),
																className: "inline-flex items-center gap-2 rounded-3xl border border-border px-4 py-2 text-sm text-foreground transition hover:border-teal-400 cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" }), "Edit book"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => handleDelete(book.book_id),
																className: "inline-flex items-center gap-2 rounded-3xl border border-destructive/40 px-4 py-2 text-sm text-destructive transition hover:bg-destructive/10 cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), "Delete book"]
															})
														]
													})]
												}, book.book_id);
											})
										})]
									})]
								}),
								view === "requests" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-3xl border border-border/60 bg-surface p-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-2xl font-semibold",
												children: "Book requests"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm text-muted-foreground",
												children: "Review reader requests for your uploaded books and accept or decline them."
											})] })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-6 flex flex-wrap gap-2 border-b border-border/60",
											children: REQUEST_TABS.map(({ key, label, icon: Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setRequestTab(key),
												className: `flex items-center gap-2 px-4 py-3 text-sm transition ${requestTab === key ? "border-b-2 border-teal-bright text-foreground" : "text-muted-foreground hover:text-foreground"}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }),
													label,
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "rounded-full bg-surface px-2 py-0.5 text-xs",
														children: counts[key]
													})
												]
											}, key))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-4",
										children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "rounded-3xl border border-border/60 bg-background p-8 text-center text-muted-foreground",
											children: "Loading requests…"
										}) : selectedRequests.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-3xl border border-border/60 bg-background p-8 text-center text-muted-foreground",
											children: [
												"No ",
												requestTab,
												" requests."
											]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-3xl border border-border/60 bg-surface p-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "hidden md:block overflow-x-auto min-w-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
													className: "w-full min-w-[700px] table-fixed text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
														className: "bg-background/40 text-left text-xs uppercase tracking-widest text-muted-foreground",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "px-5 py-3",
																children: "Book"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "px-5 py-3",
																children: "Reader"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "px-5 py-3",
																children: "Amount"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "px-5 py-3",
																children: "Requested"
															}),
															requestTab === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "px-5 py-3 text-right",
																children: "Actions"
															})
														] })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
														className: "divide-y divide-border/60",
														children: selectedRequests.map((request) => {
															const requestId = request.request_id ?? request.id ?? "";
															return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																	className: "px-5 py-4 max-w-[200px] break-words",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																			className: "font-medium",
																			children: request.book_name
																		}),
																		request.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																			className: "mt-1 text-xs text-muted-foreground",
																			children: request.note
																		}),
																		request.decline_reason && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																			className: "mt-1 text-xs text-destructive",
																			children: ["Reason: ", request.decline_reason]
																		})
																	]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																	className: "px-5 py-4 text-muted-foreground max-w-[160px] break-words",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: request.reader_name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "text-xs",
																		children: request.reader_email
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "px-5 py-4 break-words",
																	children: request.book_price != null ? `${request.currency ?? "USD"} ${request.book_price}` : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																		className: "text-muted-foreground",
																		children: "Free"
																	})
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "px-5 py-4 text-muted-foreground break-words",
																	children: new Date(request.sent_at).toLocaleDateString()
																}),
																requestTab === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "px-5 py-4",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "flex justify-end gap-2 flex-wrap",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																			type: "button",
																			onClick: () => openAcceptModal(request),
																			className: "rounded-full bg-gradient-teal px-3 py-1.5 text-xs font-medium text-primary-foreground cursor-pointer",
																			children: "Accept"
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																			type: "button",
																			onClick: () => openDeclineModal(request),
																			className: "rounded-full border border-destructive/40 px-3 py-1.5 text-xs text-destructive cursor-pointer",
																			children: "Decline"
																		})]
																	})
																})
															] }, requestId);
														})
													})]
												})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "md:hidden space-y-3",
												children: selectedRequests.map((request) => {
													const requestId = request.request_id ?? request.id ?? "";
													return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "rounded-3xl border border-border/60 bg-background p-4",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-col gap-3",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-sm font-semibold",
																		children: request.book_name
																	}),
																	request.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "mt-1 text-xs text-muted-foreground",
																		children: request.note
																	}),
																	request.decline_reason && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																		className: "mt-1 text-xs text-destructive",
																		children: ["Reason: ", request.decline_reason]
																	})
																] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "grid gap-2 text-sm text-muted-foreground",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
																			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																				className: "font-medium text-foreground",
																				children: "Reader:"
																			}),
																			" ",
																			request.reader_name
																		] }),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
																			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																				className: "font-medium text-foreground",
																				children: "Email:"
																			}),
																			" ",
																			request.reader_email
																		] }),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
																			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																				className: "font-medium text-foreground",
																				children: "Amount:"
																			}),
																			" ",
																			request.book_price != null ? `${request.currency ?? "USD"} ${request.book_price}` : "Free"
																		] }),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
																			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																				className: "font-medium text-foreground",
																				children: "Requested:"
																			}),
																			" ",
																			new Date(request.sent_at).toLocaleDateString()
																		] })
																	]
																}),
																requestTab === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "flex flex-wrap gap-2",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																		type: "button",
																		onClick: () => openAcceptModal(request),
																		className: "rounded-full bg-gradient-teal px-3 py-1.5 text-xs font-medium text-primary-foreground cursor-pointer",
																		children: "Accept"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																		type: "button",
																		onClick: () => openDeclineModal(request),
																		className: "rounded-full border border-destructive/40 px-3 py-1.5 text-xs text-destructive cursor-pointer",
																		children: "Decline"
																	})]
																})
															]
														})
													}, requestId);
												})
											})]
										})
									})]
								}),
								view === "details" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-3xl border border-border/60 bg-surface p-8 overflow-hidden min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-2xl font-semibold",
												children: "Admin details"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm text-muted-foreground",
												children: "Account details for quick access."
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-3xl border border-border/70 bg-background p-4 text-sm text-muted-foreground min-w-0 break-words",
											children: ["Role: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-foreground",
												children: isSuperAdmin ? "Super Admin" : "Admin"
											})]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 grid gap-5 grid-cols-1 lg:grid-cols-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-3xl border border-border/60 bg-background p-6 min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
													children: "Name"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-3 text-lg font-semibold break-words",
													children: user?.fullname ?? user?.email ?? "Admin"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-3xl border border-border/60 bg-background p-6 min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
													children: "Email"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-3 text-lg font-semibold break-words",
													children: user?.email ?? "—"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-3xl border border-border/60 bg-background p-6 min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
													children: "Role"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-3 text-lg font-semibold break-words",
													children: isSuperAdmin ? "Super Admin" : "Admin"
												})]
											})
										]
									})]
								}),
								view === "super-admin" && isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4 rounded-3xl border border-border/60 bg-surface p-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-2xl font-semibold",
											children: "Super Admin"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-muted-foreground",
											children: "Promote readers to admin accounts from one place."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setIsAddAdminOpen(true),
											className: "inline-flex items-center justify-center gap-2 rounded-3xl bg-teal-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-teal-700 cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4" }), "Add user as admin"]
										})]
									}), loadingUsers ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "rounded-3xl border border-border/60 bg-background p-8 text-center text-muted-foreground",
										children: "Loading users…"
									}) : users.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "rounded-3xl border border-border/60 bg-background p-8 text-center text-muted-foreground",
										children: "No users found."
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-3xl border border-border/60 bg-surface p-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "hidden md:block overflow-x-auto",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
												className: "w-full min-w-full table-fixed text-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
													className: "bg-background/40 text-left text-xs uppercase tracking-widest text-muted-foreground",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "px-5 py-3",
															children: "User"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "px-5 py-3",
															children: "Email"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "px-5 py-3",
															children: "Role"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "px-5 py-3 text-right",
															children: "Action"
														})
													] })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
													className: "divide-y divide-border/60",
													children: users.map((appUser) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "px-5 py-4",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "font-medium",
																children: appUser.fullname ?? appUser.email ?? appUser.id
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "px-5 py-4 text-muted-foreground",
															children: appUser.email ?? "—"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "px-5 py-4",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "rounded-full bg-background px-3 py-1 text-xs font-medium text-muted-foreground",
																children: appUser.role === "super-admin" ? "Super Admin" : appUser.role === "admin" ? "Admin" : "User"
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
															className: "px-5 py-4 text-right align-top",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex justify-end gap-2",
																children: [
																	appUser.role === "user" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																		type: "button",
																		disabled: promotingUserId === appUser.id && promotingAction === "admin",
																		onClick: () => promoteUserToRole(appUser.email, appUser.id, "admin"),
																		className: "rounded-full bg-gradient-teal px-3 py-1.5 text-xs font-medium text-primary-foreground disabled:opacity-60 cursor-pointer",
																		children: "Make admin"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																		type: "button",
																		disabled: promotingUserId === appUser.id && promotingAction === "super-admin",
																		onClick: () => promoteUserToRole(appUser.email, appUser.id, "super-admin"),
																		className: "rounded-full border border-teal-500 bg-teal-500/10 px-3 py-1.5 text-xs font-medium text-teal-300 disabled:opacity-60 cursor-pointer",
																		children: "Make super admin"
																	})] }),
																	appUser.role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																		type: "button",
																		disabled: promotingUserId === appUser.id && promotingAction === "super-admin",
																		onClick: () => promoteUserToRole(appUser.email, appUser.id, "super-admin"),
																		className: "rounded-full border border-teal-500 bg-teal-500/10 px-3 py-1.5 text-xs font-medium text-teal-300 disabled:opacity-60 cursor-pointer",
																		children: "Make super admin"
																	}),
																	appUser.role === "super-admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																		type: "button",
																		disabled: promotingUserId === appUser.id && promotingAction === "admin",
																		onClick: () => promoteUserToRole(appUser.email, appUser.id, "admin"),
																		className: "rounded-full border border-red-500 px-3 py-1.5 text-xs font-medium text-red-800 disabled:opacity-60 cursor-pointer",
																		children: "Remove as super admin"
																	})
																]
															}), (appUser.role === "admin" || appUser.role === "super-admin") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "mt-2 flex justify-end",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																	type: "button",
																	disabled: promotingUserId === appUser.id && promotingAction === "reader",
																	onClick: () => promoteUserToRole(appUser.email, appUser.id, "reader"),
																	className: "rounded-full border border-red-500 px-3 py-1.5 text-xs font-medium text-red-800 disabled:opacity-60 cursor-pointer",
																	children: "Remove as admin"
																})
															})]
														})
													] }, appUser.id))
												})]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "md:hidden space-y-3",
											children: users.map((appUser) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "rounded-xl border border-border/60 bg-background p-3",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "font-medium",
															children: appUser.fullname ?? appUser.email ?? appUser.id
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-xs text-muted-foreground",
															children: appUser.email ?? "—"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "mt-2",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "rounded-full bg-surface px-2 py-1 text-xs font-medium text-muted-foreground",
																children: appUser.role === "super-admin" ? "Super Admin" : appUser.role === "admin" ? "Admin" : "User"
															})
														})
													] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex flex-col items-start gap-2",
														children: [
															appUser.role === "user" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => promoteUserToRole(appUser.email, appUser.id, "admin"),
																className: "rounded-full bg-gradient-teal px-3 py-1.5 text-xs font-medium text-primary-foreground cursor-pointer",
																children: "Make admin"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => promoteUserToRole(appUser.email, appUser.id, "super-admin"),
																className: "rounded-full border border-teal-500 bg-teal-500/10 px-3 py-1.5 text-xs font-medium text-teal-300 cursor-pointer",
																children: "Make super admin"
															})] }),
															appUser.role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => promoteUserToRole(appUser.email, appUser.id, "super-admin"),
																className: "rounded-full border border-teal-500 bg-teal-500/10 px-3 py-1.5 text-xs font-medium text-teal-300 cursor-pointer",
																children: "Make super admin"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => promoteUserToRole(appUser.email, appUser.id, "reader"),
																className: "rounded-full border border-red-500 px-3 py-1.5 text-xs font-medium text-red-800 cursor-pointer",
																children: "Remove as admin"
															})] }),
															appUser.role === "super-admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => promoteUserToRole(appUser.email, appUser.id, "admin"),
																className: "rounded-full border border-red-500 px-3 py-1.5 text-xs font-medium text-red-800 cursor-pointer",
																children: "Remove as super admin"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => promoteUserToRole(appUser.email, appUser.id, "reader"),
																className: "rounded-full border border-red-500 px-3 py-1.5 text-xs font-medium text-red-800 mt-2 cursor-pointer",
																children: "Remove as admin"
															})] })
														]
													})]
												})
											}, appUser.id))
										})]
									})]
								})
							]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: acceptModalOpen,
				onOpenChange: setAcceptModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-[425px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Accept Request" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						"Are you sure you want to accept this book request from ",
						acceptTarget?.reader_name,
						"?"
					] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
						className: "gap-2 sm:gap-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setAcceptModalOpen(false),
							className: "rounded-3xl border border-border px-4 py-2 text-sm font-semibold transition hover:bg-muted cursor-pointer bg-transparent text-foreground",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: acceptSubmitting,
							onClick: confirmAcceptRequest,
							className: "rounded-3xl bg-teal-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-teal-700 disabled:opacity-60 cursor-pointer",
							children: acceptSubmitting ? "Accepting..." : "Yes, Accept"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: declineModalOpen,
				onOpenChange: setDeclineModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-[425px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Decline Request" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Are you sure you want to decline?" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-2 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "declineReason",
								className: "text-sm font-medium text-foreground",
								children: "Reason for decline"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								id: "declineReason",
								rows: 4,
								value: declineReason,
								onChange: (e) => setDeclineReason(e.target.value),
								placeholder: "Enter reason for declining...",
								className: "w-full rounded-2xl border border-border/60 bg-background px-4 py-3 text-sm text-foreground outline-none transition focus:border-teal-400 resize-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "gap-2 sm:gap-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDeclineModalOpen(false),
								className: "rounded-3xl border border-border px-4 py-2 text-sm font-semibold transition hover:bg-muted cursor-pointer bg-transparent text-foreground",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: declineSubmitting,
								onClick: confirmDeclineRequest,
								className: "rounded-3xl bg-destructive px-4 py-2 text-sm font-semibold text-destructive-foreground transition hover:opacity-90 disabled:opacity-60 cursor-pointer",
								children: declineSubmitting ? "Declining..." : "Decline Request"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: reportModalOpen,
				onOpenChange: setReportModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-[1200px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Book Report" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
							"Analytics and reader performance statistics for ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-foreground",
								children: reportBook?.book_name
							}),
							"."
						] })] }),
						reportLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "py-8 text-center text-sm text-muted-foreground",
							children: "Loading report statistics…"
						}) : !isMobileView ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableForm, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 py-4 text-sm max-h-[60vh] overflow-y-auto pr-1",
							children: [
								{
									key: "pending",
									label: "Pending Requests",
									count: bookReport?.pendingList?.length ?? 0,
									list: bookReport?.pendingList,
									colorClass: "text-teal-600 bg-teal-500/10"
								},
								{
									key: "accepted",
									label: "Accepted Requests",
									count: bookReport?.acceptedList?.length ?? 0,
									list: bookReport?.acceptedList,
									colorClass: "text-teal-600 bg-teal-500/10"
								},
								{
									key: "declined",
									label: "Declined Requests",
									count: bookReport?.declinedList?.length ?? 0,
									list: bookReport?.declinedList,
									colorClass: "text-destructive bg-destructive/10"
								},
								{
									key: "completed",
									label: "Readers Completed",
									count: bookReport?.completedList?.length ?? 0,
									list: bookReport?.completedList,
									colorClass: "text-teal-600 bg-teal-500/10"
								},
								{
									key: "inProgress",
									label: "Readers Currently Reading",
									count: bookReport?.inProgressList?.length ?? 0,
									list: bookReport?.inProgressList,
									colorClass: "text-teal-600 bg-teal-500/10"
								}
							].map((category) => {
								const isExpanded = !!expandedCategories[category.key];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-border/60 bg-background/50 backdrop-blur-sm overflow-hidden transition-all duration-200",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => toggleCategory(category.key),
										className: "flex w-full items-center justify-between p-4 text-left font-medium hover:bg-muted/40 transition cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-foreground",
												children: category.label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `inline-flex items-center justify-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${category.colorClass}`,
												children: category.count
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-4 w-4 text-muted-foreground transition-transform duration-200 ${isExpanded ? "rotate-180" : ""}` })]
									}), isExpanded && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "border-t border-border/40 bg-muted/10 p-4 transition-all duration-300",
										children: !category.list || category.list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-muted-foreground py-2 text-center",
											children: "No readers in this category."
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "space-y-3 max-h-48 overflow-y-auto pr-1",
											children: category.list.map((reader, idx) => {
												const getInitials = (n) => {
													if (!n) return "?";
													return n.split(" ").map((p) => p[0]).join("").toUpperCase().slice(0, 2);
												};
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3 py-1 first:pt-0 last:pb-0 border-b border-border/10 last:border-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-teal-500/10 text-teal-600 font-semibold text-xs",
														children: getInitials(reader.name)
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "min-w-0 flex-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "font-medium text-foreground truncate text-sm",
															children: reader.name
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-xs text-muted-foreground truncate",
															children: reader.email
														})]
													})]
												}, idx);
											})
										})
									})]
								}, category.key);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "gap-2 sm:gap-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: reportLoading || !bookReport,
								onClick: exportReportToXLSX,
								className: "inline-flex items-center gap-2 rounded-3xl bg-teal-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-teal-700 disabled:opacity-60 cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), "Export to XLSX"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setReportModalOpen(false),
								className: "rounded-3xl border border-border px-4 py-2 text-sm font-semibold transition hover:bg-muted cursor-pointer bg-transparent text-foreground",
								children: "Close"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isAddAdminOpen,
				onOpenChange: setIsAddAdminOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-[425px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add User as Admin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Promote a user by entering their email address and selecting their new role." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleAddAdmin,
						className: "space-y-4 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "email",
									className: "text-sm font-medium text-foreground",
									children: "User Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "email",
									type: "email",
									required: true,
									placeholder: "user@example.com",
									value: addAdminEmail,
									onChange: (e) => setAddAdminEmail(e.target.value),
									className: "w-full rounded-2xl border border-border/60 bg-background px-4 py-3 text-sm text-foreground outline-none transition focus:border-teal-400"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "role",
									className: "text-sm font-medium text-foreground",
									children: "Role"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "role",
									value: addAdminRole,
									onChange: (e) => setAddAdminRole(e.target.value),
									className: "w-full rounded-2xl border border-border/60 bg-background px-4 py-3 text-sm text-foreground outline-none transition focus:border-teal-400",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "admin",
										children: "Admin"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "super-admin",
										children: "Super Admin"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-3 pt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setIsAddAdminOpen(false),
									className: "rounded-3xl border border-border px-4 py-2 text-sm font-semibold transition hover:bg-muted cursor-pointer bg-transparent text-foreground",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: isSubmittingAddAdmin,
									className: "rounded-3xl bg-teal-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-teal-700 disabled:opacity-60 cursor-pointer",
									children: isSubmittingAddAdmin ? "Updating..." : "Add Admin"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAdmin, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminDashboard, {}) });
//#endregion
export { SplitComponent as component };
