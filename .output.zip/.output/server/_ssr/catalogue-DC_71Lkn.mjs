import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useAuth } from "./use-auth-CIaruFYY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as SiteHeader } from "./site-header-CgAShUuv.mjs";
import { t as SiteFooter } from "./site-footer-DlsoCshG.mjs";
import { r as genres } from "./books-B4AwiTZV.mjs";
import { t as BookCard } from "./book-card-80Ale8-j.mjs";
import { t as Route } from "./catalogue-CZ2ARXiL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalogue-DC_71Lkn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Catalogue() {
	const { q: initialQ } = Route.useSearch();
	const { user, loading, backendUrl } = useAuth();
	const [books, setBooks] = (0, import_react.useState)([]);
	const [loadingBooks, setLoadingBooks] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	const [q, setQ] = (0, import_react.useState)(initialQ);
	const [genre, setGenre] = (0, import_react.useState)("All");
	const [status, setStatus] = (0, import_react.useState)("All");
	const [sort, setSort] = (0, import_react.useState)("rating");
	(0, import_react.useEffect)(() => {
		const fetchBooks = async () => {
			setLoadingBooks(true);
			setError(null);
			try {
				const res = await fetch(`${backendUrl}/all_books`);
				if (!res.ok) throw new Error(`Failed to load books: ${res.status} ${res.statusText}`);
				setBooks((await res.json() ?? []).map((item) => ({
					id: item.book_id,
					title: item.book_name,
					author: item.author_name ?? "Unknown author",
					authorId: item.author_id ?? item.author_name?.toLowerCase().replace(/\s+/g, "-") ?? "unknown",
					cover: item.book_cover_url ?? "",
					genre: item.category ?? "Unknown",
					status: item.status === "Complete" ? "Complete" : "Serialised",
					chapters: item.chapters ?? item.pages ?? 0,
					rating: item.rating ?? 0,
					price: item.subscription_price ?? 0,
					currency: item.currency ?? "USD",
					synopsis: item.synopsis ?? item.description ?? ""
				})));
			} catch (err) {
				console.error(err);
				setError(err instanceof Error ? err.message : "Unable to load catalogue.");
			} finally {
				setLoadingBooks(false);
			}
		};
		fetchBooks();
	}, [backendUrl]);
	const results = (0, import_react.useMemo)(() => {
		return books.filter((b) => (genre === "All" || b.genre === genre) && (status === "All" || b.status === status) && (q === "" || `${b.title} ${b.genre}`.toLowerCase().includes(q.toLowerCase()))).sort((a, b) => {
			if (sort === "rating") return b.rating - a.rating;
			if (sort === "chapters") return b.chapters - a.chapters;
			return a.title.localeCompare(b.title);
		});
	}, [
		books,
		q,
		genre,
		status,
		sort
	]);
	if (!loading && !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-xl px-4 py-20 text-center sm:px-6 sm:py-32",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl",
						children: "Sign in to view the library"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted-foreground",
						children: "The full LITN medical-training library is available to signed-in members. Create a free account or sign in to browse every title."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "rounded-full bg-gradient-teal px-6 py-3 text-sm font-medium text-primary-foreground shadow-glow",
							children: "Sign in"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/signup",
							className: "rounded-full border border-border bg-surface px-6 py-3 text-sm font-medium text-foreground",
							children: "Create account"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 pt-10 pb-16 sm:px-6 sm:pt-12 sm:pb-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl sm:text-4xl md:text-5xl",
						children: "The Library"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted-foreground",
						children: [results.length, " medical-training titles available."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 grid gap-3 rounded-2xl border border-border/60 bg-surface p-4 sm:grid-cols-2 xl:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: q,
								onChange: (e) => setQ(e.target.value),
								placeholder: "Search titles or subjects…",
								className: "w-full rounded-full border border-border bg-background/60 px-4 py-2 text-sm outline-none focus:border-primary sm:col-span-2 xl:col-span-1"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: genre,
								onChange: (e) => setGenre(e.target.value),
								className: "w-full rounded-full border border-border bg-background/60 px-4 py-2 text-sm",
								children: genres.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: g }, g))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: status,
								onChange: (e) => setStatus(e.target.value),
								className: "w-full rounded-full border border-border bg-background/60 px-4 py-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "All" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Serialised" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Complete" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: sort,
								onChange: (e) => setSort(e.target.value),
								className: "w-full rounded-full border border-border bg-background/60 px-4 py-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "rating",
										children: "Top rated"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "chapters",
										children: "Most chapters"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "title",
										children: "A–Z"
									})
								]
							})
						]
					}),
					loadingBooks ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-16 text-center text-muted-foreground",
						children: "Loading catalogue…"
					}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-16 rounded-2xl border border-red-200 bg-red-50 p-6 text-center text-sm text-red-900",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Unable to load books." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: error
						})]
					}) : results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-16 text-center text-muted-foreground",
						children: "No books match those filters yet."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5",
						children: results.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCard, { book: b }, b.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Catalogue as component };
