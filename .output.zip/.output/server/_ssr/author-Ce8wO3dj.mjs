import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/author-Ce8wO3dj.js
var import_jsx_runtime = require_jsx_runtime();
var SplitErrorComponent = ({ reset }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	onClick: reset,
	children: "retry"
});
//#endregion
export { SplitErrorComponent as errorComponent };
