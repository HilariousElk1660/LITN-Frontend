import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book._id-DcDfrAra.js
var $$splitComponentImporter = () => import("./book._id-HRCoAn22.mjs");
var $$splitErrorComponentImporter = () => import("./book._id-Cwf934ls.mjs");
var $$splitNotFoundComponentImporter = () => import("./book._id-BuaLJPmX.mjs");
var Route = createFileRoute("/book/$id")({
	loader: ({ params }) => {
		return true;
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
