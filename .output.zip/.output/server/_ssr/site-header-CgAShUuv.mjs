import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useAuth } from "./use-auth-CIaruFYY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ChevronDown, i as User, l as Shield, m as LogOut, p as Menu, r as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-header-CgAShUuv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var logo1_default = "/assets/logo1-CwQrH5-r.png";
function SiteHeader() {
	const { user, isAdmin, isSuperAdmin, signOut, loading } = useAuth();
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [mobileNavOpen, setMobileNavOpen] = (0, import_react.useState)(false);
	const menuRef = (0, import_react.useRef)(null);
	const mobileNavRef = (0, import_react.useRef)(null);
	const initials = (user?.fullname || user?.email || "?").split(" ").map((part) => part[0]).slice(0, 2).join("").toUpperCase();
	(0, import_react.useEffect)(() => {
		function handleClickOutside(e) {
			const target = e.target;
			if (menuRef.current && !menuRef.current.contains(target)) setMenuOpen(false);
			if (mobileNavRef.current && !mobileNavRef.current.contains(target)) setMobileNavOpen(false);
		}
		function handleEscape(e) {
			if (e.key === "Escape") {
				setMenuOpen(false);
				setMobileNavOpen(false);
			}
		}
		document.addEventListener("mousedown", handleClickOutside);
		document.addEventListener("keydown", handleEscape);
		return () => {
			document.removeEventListener("mousedown", handleClickOutside);
			document.removeEventListener("keydown", handleEscape);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-border/60 bg-background/70 backdrop-blur-xl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full min-h-16 max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: logo1_default,
						alt: "",
						className: "h-12 w-12 rounded-md object-contain sm:h-[90px] sm:w-[90px]"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-8 text-sm text-muted-foreground md:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "transition-colors hover:text-foreground",
							activeOptions: { exact: true },
							activeProps: { className: "text-foreground" },
							children: "Home"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/catalogue",
							className: "transition-colors hover:text-foreground",
							activeProps: { className: "text-foreground" },
							children: "Catalogue"
						}),
						isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/admin",
							className: "text-teal-bright transition-colors hover:text-foreground",
							activeProps: { className: "text-foreground" },
							children: "Admin"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative ml-auto flex items-center gap-2",
					ref: mobileNavRef,
					children: [
						loading ? null : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							ref: menuRef,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setMenuOpen((o) => !o),
								className: "flex items-center gap-2 rounded-full border border-transparent px-2 py-1 text-sm text-muted-foreground transition hover:border-border hover:text-foreground",
								"aria-haspopup": "menu",
								"aria-expanded": menuOpen,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex h-7 w-7 items-center justify-center rounded-full bg-gradient-teal text-[11px] font-semibold text-primary-foreground",
										children: initials
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: user.email
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `hidden h-3.5 w-3.5 transition-transform sm:inline ${menuOpen ? "rotate-180" : ""}` })
								]
							}), menuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								role: "menu",
								className: "absolute right-0 top-full mt-2 w-56 overflow-hidden rounded-xl border border-border/60 bg-background/95 shadow-lg backdrop-blur-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border-b border-border/60 px-4 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm font-medium text-foreground",
											children: user.fullname || "My account"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-xs text-muted-foreground",
											children: user.email
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "py-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/profile",
											onClick: () => setMenuOpen(false),
											className: "flex items-center gap-2 px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted hover:text-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4" }), "Profile"]
										}), isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/admin",
											onClick: () => setMenuOpen(false),
											className: "flex items-center gap-2 px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted hover:text-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-4 w-4" }), "Admin"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "border-t border-border/60 py-1",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => {
												setMenuOpen(false);
												signOut();
											},
											className: "flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-muted-foreground transition hover:bg-muted hover:text-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), "Sign out"]
										})
									})
								]
							})]
						}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "hidden rounded-full px-3 py-2 text-sm text-muted-foreground transition hover:text-foreground sm:inline-flex",
							children: "Sign in"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/signup",
							className: "rounded-full bg-gradient-teal px-3 py-2 text-xs font-medium text-primary-foreground shadow-glow transition hover:opacity-90 sm:px-4 sm:py-2 sm:text-sm",
							children: "Sign up"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMobileNavOpen((o) => !o),
							className: "inline-flex h-10 w-10 items-center justify-center rounded-full border border-border/60 bg-surface/80 text-foreground transition hover:border-primary md:hidden",
							"aria-label": "Toggle navigation",
							"aria-expanded": mobileNavOpen,
							children: mobileNavOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" })
						}),
						mobileNavOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute right-0 top-full mt-2 w-56 overflow-hidden rounded-xl border border-border/60 bg-background/95 shadow-lg backdrop-blur-xl md:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b border-border/60 px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-foreground",
									children: "Navigate"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Quick links and account actions"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/",
										onClick: () => setMobileNavOpen(false),
										className: "px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted hover:text-foreground",
										children: "Home"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/catalogue",
										onClick: () => setMobileNavOpen(false),
										className: "px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted hover:text-foreground",
										children: "Catalogue"
									}),
									isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/admin",
										onClick: () => setMobileNavOpen(false),
										className: "px-4 py-2 text-sm text-teal-bright transition hover:bg-muted hover:text-foreground",
										children: "Admin"
									}),
									user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/profile",
										onClick: () => setMobileNavOpen(false),
										className: "px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted hover:text-foreground",
										children: "Profile"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											setMobileNavOpen(false);
											signOut();
										},
										className: "flex items-center gap-2 px-4 py-2 text-left text-sm text-muted-foreground transition hover:bg-muted hover:text-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), "Sign out"]
									})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/login",
										onClick: () => setMobileNavOpen(false),
										className: "px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted hover:text-foreground",
										children: "Sign in"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/signup",
										onClick: () => setMobileNavOpen(false),
										className: "px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted hover:text-foreground",
										children: "Sign up"
									})] })
								]
							})]
						})
					]
				})
			]
		})
	});
}
//#endregion
export { SiteHeader as t };
