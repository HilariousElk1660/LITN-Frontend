import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useAuth } from "./use-auth-CIaruFYY.mjs";
import { F as useRouter, g as Link, l as useCanGoBack } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as ChevronLeft, T as ChevronRight, d as RotateCw, j as ArrowLeft, n as ZoomIn, t as ZoomOut } from "../_libs/lucide-react.mjs";
import { t as Route } from "./read._id-DRrvl1vt.mjs";
import { r as GlobalWorkerOptions, s as version } from "../_libs/pdfjs-dist.mjs";
import { n as Document, t as Page } from "../_libs/react-pdf+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/read._id-D4bHe2tW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${version}/build/pdf.worker.min.mjs`;
function PdfViewer({ initialPage = 5, file, book_id }) {
	const isMobile = window.matchMedia("(max-width: 768px)").matches;
	const { user, backendUrl } = useAuth();
	const [numPages, setNumPages] = (0, import_react.useState)(null);
	const [pageNumber, setPageNumber] = (0, import_react.useState)(initialPage);
	const [scale, setScale] = (0, import_react.useState)(isMobile ? .8 : 2.8);
	const [rotation, setRotation] = (0, import_react.useState)(0);
	const containerRef = (0, import_react.useRef)(null);
	const pageRefs = (0, import_react.useRef)([]);
	const hasScrolledToInitial = (0, import_react.useRef)(false);
	function onDocumentLoadSuccess({ numPages }) {
		setNumPages(numPages);
		pageRefs.current = Array(numPages).fill(null);
	}
	console.log("FILE", typeof file);
	(0, import_react.useEffect)(() => {
		if (!hasScrolledToInitial.current && numPages && pageRefs.current[initialPage - 1]) {
			pageRefs.current[initialPage - 1].scrollIntoView({ block: "start" });
			setPageNumber(initialPage);
			hasScrolledToInitial.current = true;
		}
	}, [numPages, initialPage]);
	function scrollToPage(n) {
		const target = pageRefs.current[n - 1];
		if (target && containerRef.current) {
			target.scrollIntoView({
				behavior: "smooth",
				block: "start"
			});
			setPageNumber(n);
		}
	}
	function goToPrevPage() {
		scrollToPage(Math.max(pageNumber - 1, 1));
	}
	function goToNextPage() {
		scrollToPage(Math.min(pageNumber + 1, numPages ?? pageNumber));
	}
	function zoomIn() {
		setScale((prev) => Math.min(prev + .2, 3));
	}
	function zoomOut() {
		setScale((prev) => Math.max(prev - .2, .4));
	}
	function rotate() {
		setRotation((prev) => (prev + 90) % 360);
	}
	const handleScroll = (0, import_react.useCallback)(() => {
		const container = containerRef.current;
		if (!container) return;
		const containerTop = container.getBoundingClientRect().top;
		let closestPage = 1;
		let closestDistance = Infinity;
		pageRefs.current.forEach((el, idx) => {
			if (!el) return;
			const distance = Math.abs(el.getBoundingClientRect().top - containerTop);
			if (distance < closestDistance) {
				closestDistance = distance;
				closestPage = idx + 1;
			}
		});
		setPageNumber(closestPage);
	}, []);
	const pageNumberRef = (0, import_react.useRef)(pageNumber);
	(0, import_react.useEffect)(() => {
		pageNumberRef.current = pageNumber;
	}, [pageNumber]);
	(0, import_react.useEffect)(() => {
		if (!book_id) return;
		const base = backendUrl;
		const readerId = user?.user_id;
		const delayDebounceFn = setTimeout(() => {
			fetch(`${base}/save_reading_progress?reader_id=${readerId}&book_id=${book_id}&page_stopped_at=${pageNumber}`, { method: "POST" }).catch((err) => console.error("Failed to save progress:", err));
		}, 2e3);
		return () => clearTimeout(delayDebounceFn);
	}, [
		pageNumber,
		book_id,
		user?.id,
		backendUrl
	]);
	(0, import_react.useEffect)(() => {
		const saveProgress = () => {
			if (!book_id) return;
			const url = `${backendUrl}/save_reading_progress?reader_id=${user?.id || "1dd309e3-31d0-4f53-b58a-f1d36e6a1dc4"}&book_id=${book_id}&page_stopped_at=${pageNumberRef.current}`;
			navigator.sendBeacon(url);
		};
		window.addEventListener("pagehide", saveProgress);
		window.addEventListener("beforeunload", saveProgress);
		return () => {
			window.removeEventListener("pagehide", saveProgress);
			window.removeEventListener("beforeunload", saveProgress);
			saveProgress();
		};
	}, [
		book_id,
		user?.id,
		backendUrl
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-3 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `sticky ${isMobile ? "mt-10" : "mt-2"} top-2 z-10 flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 shadow-sm`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: goToPrevPage,
					disabled: pageNumber <= 1,
					className: "p-1.5 rounded hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed",
					"aria-label": "Previous page",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { size: 18 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm tabular-nums min-w-[70px] text-center",
					children: [
						pageNumber,
						" / ",
						numPages ?? "–"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: goToNextPage,
					disabled: !numPages || pageNumber >= numPages,
					className: "p-1.5 rounded hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed",
					"aria-label": "Next page",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 18 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px h-5 bg-border mx-1" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: zoomOut,
					disabled: scale <= .4,
					className: "p-1.5 rounded hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed",
					"aria-label": "Zoom out",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { size: 18 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm tabular-nums min-w-[45px] text-center",
					children: [Math.round(scale * 100), "%"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: zoomIn,
					disabled: scale >= 3,
					className: "p-1.5 rounded hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed",
					"aria-label": "Zoom in",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { size: 18 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px h-5 bg-border mx-1" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: rotate,
					className: "p-1.5 rounded hover:bg-muted",
					"aria-label": "Rotate",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { size: 18 })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: containerRef,
			onScroll: handleScroll,
			className: "w-full max-h-[92vh] overflow-y-auto rounded-lg border border-border bg-muted/30",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Document, {
				file,
				onLoadSuccess: onDocumentLoadSuccess,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col items-center gap-4 p-4",
					children: numPages && Array.from({ length: numPages }, (_, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: (el) => pageRefs.current[idx] = el,
						className: "shadow-lg border border-border rounded-lg overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
							pageNumber: idx + 1,
							scale,
							rotate: rotation,
							renderTextLayer: false,
							renderAnnotationLayer: false
						})
					}, idx))
				})
			})
		})]
	});
}
function BackButton({ bookId }) {
	const router = useRouter();
	const canGoBack = useCanGoBack();
	const handleBack = () => {
		if (canGoBack) router.history.back();
		else router.navigate({
			to: "/book/$id",
			params: { id: bookId }
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: handleBack,
		"aria-label": "Back",
		className: "fixed left-4 top-4 z-50 flex items-center cursor-pointer gap-2 rounded-full bg-background/80 px-4 py-2 text-sm font-medium shadow-sm backdrop-blur transition hover:bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), "Back"]
	});
}
function AccessGate({ bookId, children }) {
	const { user, isAdmin, loading } = useAuth();
	const [state, setState] = (0, import_react.useState)("checking");
	(0, import_react.useEffect)(() => {
		setState("granted");
	}, [
		user,
		isAdmin,
		loading,
		bookId
	]);
	if (loading || state === "checking") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center text-muted-foreground",
		children: "Checking access…"
	});
	if (state === "denied") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-screen max-w-md flex-col items-center justify-center gap-4 px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Access required"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground",
				children: user ? "Your purchase request must be approved before you can read this book." : "Sign in and request access to read this book."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/book/$id",
				params: { id: bookId },
				className: "rounded-full bg-gradient-teal px-5 py-3 text-sm font-medium text-primary-foreground",
				children: "Back to book"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function Reader() {
	const [book, setBook] = (0, import_react.useState)(null);
	const [pageStoppedAt, setPageStoppedAt] = (0, import_react.useState)(0);
	const { id } = Route.useParams();
	const { chapter } = Route.useSearch();
	const { user, loading, backendUrl } = useAuth();
	const fetchBook = async (bookId) => {
		try {
			const base = backendUrl;
			const res = await fetch(`${base}/read_book/${bookId}`);
			if (!res.ok) throw new Error("Failed to fetch book " + res.statusText);
			const bookData = await res.json();
			setBook({
				...bookData,
				"pdf_file_url": JSON.parse(bookData.pdf_file_url)
			});
			console.log(bookData);
			const readerId = user?.user_id;
			const res2 = await fetch(`${base}/reading_progress?book_id=${bookId}&reader_id=${readerId}`);
			if (res2.ok) {
				const data = await res2.json();
				let page = chapter ? Number(chapter) : data.current_page !== void 0 ? Number(data.current_page) : 1;
				console.log("page", page);
				setPageStoppedAt(page);
			}
		} catch (e) {
			console.error("Error fetching book:", e);
		}
	};
	(0, import_react.useEffect)(() => {
		if (!loading) fetchBook(id);
	}, [
		id,
		loading,
		user?.user_id,
		backendUrl
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccessGate, {
		bookId: "d",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { bookId: id }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReaderInner, {
			book,
			pageStoppedAt,
			book_id: id
		})]
	});
}
function ReaderInner({ book, pageStoppedAt, book_id }) {
	const { user } = useAuth();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center text-muted-foreground",
		children: "Loading reader…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-h-screen items-center justify-center text-muted-foreground",
			children: "Loading book…"
		}),
		children: !pageStoppedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-h-screen items-center justify-center text-muted-foreground",
			children: "Loading book…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdfViewer, {
			initialPage: pageStoppedAt,
			file: book?.pdf_file_url[user?.prefferedLanguage || "english"],
			book_id
		})
	});
}
//#endregion
export { Reader as component };
