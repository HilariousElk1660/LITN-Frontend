//#region node_modules/.nitro/vite/services/ssr/assets/books-B4AwiTZV.js
var cover_1_default = "/assets/cover-1-BYEYQnLR.jpg";
var cover_2_default = "/assets/cover-2-nUm4dB_G.jpg";
var cover_3_default = "/assets/cover-3-DZJm1cjc.jpg";
var cover_4_default = "/assets/cover-4-DEFhf-UY.jpg";
var cover_5_default = "/assets/cover-5-D0Y0D4Et.jpg";
var cover_6_default = "/assets/cover-6-BGDlK9El.jpg";
var PAYMENT_INFO = {
	provider: "MTN Mobile Money",
	number: "+260 97 123 4567",
	accountName: "LITN Medical Training",
	reviewWindow: "within 24 hours"
};
var books = [
	{
		id: "clinical-anatomy-essentials",
		title: "Clinical Anatomy Essentials",
		author: "Dr. M. Okafor",
		authorId: "m-okafor",
		cover: cover_1_default,
		genre: "Anatomy",
		status: "Complete",
		chapters: 18,
		rating: 4.8,
		price: 15,
		currency: "USD",
		synopsis: "A concise, exam-oriented walkthrough of clinical anatomy — regional dissection, surface landmarks, and high-yield correlations for medical students and interns."
	},
	{
		id: "pharmacology-in-practice",
		title: "Pharmacology in Practice",
		author: "Dr. D. Reyes",
		authorId: "d-reyes",
		cover: cover_2_default,
		genre: "Pharmacology",
		status: "Complete",
		chapters: 22,
		rating: 4.6,
		price: 18,
		currency: "USD",
		synopsis: "Mechanisms, indications, contraindications, and prescribing pearls across the major drug classes, with case-based dosing scenarios."
	},
	{
		id: "emergency-medicine-handbook",
		title: "Emergency Medicine Handbook",
		author: "Dr. V. Solenne",
		authorId: "v-solenne",
		cover: cover_3_default,
		genre: "Emergency Medicine",
		status: "Serialised",
		chapters: 14,
		rating: 4.9,
		price: 20,
		currency: "USD",
		synopsis: "Structured, protocol-driven guidance for the first ten minutes of a resuscitation — airway, shock, trauma, toxicology and paediatric emergencies."
	},
	{
		id: "clinical-ecg-mastery",
		title: "Clinical ECG Mastery",
		author: "Dr. I. Ang",
		authorId: "i-ang",
		cover: cover_4_default,
		genre: "Cardiology",
		status: "Complete",
		chapters: 16,
		rating: 4.7,
		price: 16,
		currency: "USD",
		synopsis: "From axis and intervals to ischaemia, arrhythmia and pacing artefacts — read any ECG systematically, with 120 annotated tracings."
	},
	{
		id: "surgical-skills-primer",
		title: "Surgical Skills Primer",
		author: "Dr. T. Brandt",
		authorId: "t-brandt",
		cover: cover_5_default,
		genre: "Surgery",
		status: "Complete",
		chapters: 12,
		rating: 4.5,
		price: 17,
		currency: "USD",
		synopsis: "Suturing, knot-tying, scrubbing, and the ward-round etiquette every junior surgeon needs before their first theatre list."
	},
	{
		id: "internal-medicine-review",
		title: "Internal Medicine Review",
		author: "Dr. A. Park",
		authorId: "a-park",
		cover: cover_6_default,
		genre: "Internal Medicine",
		status: "Serialised",
		chapters: 24,
		rating: 4.8,
		price: 22,
		currency: "USD",
		synopsis: "A board-review companion covering cardiology, pulmonology, nephrology, endocrinology, and infectious disease with rapid-recall summaries."
	}
];
var genres = [
	"All",
	"Anatomy",
	"Pharmacology",
	"Emergency Medicine",
	"Cardiology",
	"Surgery",
	"Internal Medicine"
];
//#endregion
export { books as n, genres as r, PAYMENT_INFO as t };
