import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useAuth, n as api } from "./use-auth-CIaruFYY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as CircleCheck, h as Info, r as X, x as Copy } from "../_libs/lucide-react.mjs";
import { t as SiteHeader } from "./site-header-CgAShUuv.mjs";
import { t as SiteFooter } from "./site-footer-DlsoCshG.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PAYMENT_INFO } from "./books-B4AwiTZV.mjs";
import { n as useBooks } from "./use-books-B0GzInlS.mjs";
import { t as Route } from "./book._id-DcDfrAra.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book._id-HRCoAn22.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PurchaseRequestButton({ bookId, adminId, bookTitle, price, currency }) {
	const { user, loading, backendUrl } = useAuth();
	const { bookRequests, setBookRequests } = useBooks();
	const [status, setStatus] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	console.log("requests", bookRequests);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		if (bookRequests) setStatus(bookRequests.find((book) => book.book_id == bookId)?.status);
	}, [
		user,
		bookId,
		bookRequests
	]);
	if (loading) return null;
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/login",
		className: "mt-2 flex w-full justify-center rounded-full border border-border bg-surface px-5 py-3 text-sm",
		children: "Sign in to order this book"
	});
	if (status === "paid") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 w-full rounded-full border border-teal-bright/40 bg-teal/10 px-5 py-3 text-center text-sm text-teal-bright",
		children: "✓ Order approved"
	});
	if (status === "pending") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 space-y-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full rounded-2xl border border-border bg-surface px-5 py-4 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 font-medium text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "h-4 w-4 text-teal-bright" }), " Order received — awaiting payment confirmation"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted-foreground",
					children: [
						"We're checking for your Mobile Money payment. Once an admin confirms it (usually ",
						PAYMENT_INFO.reviewWindow,
						"), this book unlocks automatically on your account."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted-foreground",
					children: [
						"If you haven't paid yet, send ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold text-foreground",
							children: [
								currency,
								" ",
								price
							]
						}),
						" to",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: PAYMENT_INFO.number
						}),
						" (",
						PAYMENT_INFO.provider,
						") and use ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: user.email
						}),
						" as the reference."
					]
				})
			]
		})
	});
	const submit = async () => {
		setBusy(true);
		const payload = {
			book_id: bookId,
			admin_id: adminId,
			reader_id: user?.user_id,
			reader_name: user?.fullname,
			reader_email: user?.email,
			book_name: bookTitle,
			book_price: price
		};
		const token = api.getToken();
		try {
			const res = await fetch(`${backendUrl}/book_request`, {
				"method": "POST",
				"headers": {
					"Content-Type": "application/json",
					"Authorization": `Bearer ${token}`
				},
				"body": JSON.stringify(payload)
			});
			const data = await res.json();
			console.log("NEW", data);
			if (res.ok) {
				setOpen(false);
				setBookRequests([...bookRequests, data?.new_request[0]]);
			} else {
				toast.error("Was unable to send book request please try again later");
				setOpen(false);
			}
		} catch (e) {
			console.error("error sending book request", e);
		} finally {
			setBusy(false);
		}
	};
	const copy = (text) => {
		navigator.clipboard.writeText(text).then(() => toast.success("Copied"), () => toast.error("Couldn't copy"));
	};
	if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick: () => setOpen(true),
		className: "mt-2 w-full rounded-full bg-gradient-teal px-5 py-3 text-sm font-semibold text-primary-foreground shadow-glow transition hover:opacity-90",
		children: status === "declined" ? `Order again — ${currency} ${price}` : `Order this book — ${currency} ${price}`
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0",
			onClick: () => setOpen(false),
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl border border-border bg-surface p-5 text-sm shadow-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-display text-lg text-foreground",
						children: ["Order ", bookTitle]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted-foreground",
						children: "Pay by Mobile Money — no card required. Follow the three steps below."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setOpen(false),
						className: "rounded-full border border-border p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors",
						"aria-label": "Close Modal",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between rounded-xl border border-border/60 bg-background/40 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-muted-foreground",
						children: "Amount due"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-display text-xl text-foreground",
						children: [
							currency,
							" ",
							price
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-5 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
							n: 1,
							title: `Send ${currency} ${price} via ${PAYMENT_INFO.provider}`,
							body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Number",
										value: PAYMENT_INFO.number,
										onCopy: () => copy(PAYMENT_INFO.number)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Account name",
										value: PAYMENT_INFO.accountName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Amount",
										value: `${currency} ${price}`,
										onCopy: () => copy(String(price))
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
							n: 2,
							title: "Use your email as the payment reference",
							body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Reference",
									value: user.email ?? "",
									onCopy: () => copy(user.email ?? "")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-muted-foreground",
									children: "This is how we match your payment to your account. Without it, confirmation is delayed."
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
							n: 3,
							title: "Submit your order for review",
							body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-muted-foreground",
								children: [
									"Tap the button below after you've sent the money. An admin will confirm your payment ",
									PAYMENT_INFO.reviewWindow,
									", and this book will unlock automatically on your account — you'll see the change here without refreshing."
								]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 rounded-xl border border-teal/20 bg-teal/5 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-teal-bright",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-semibold uppercase tracking-widest",
							children: "What happens next"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 space-y-1 text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"• Your order is created with status ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground",
									children: "Pending"
								}),
								"."
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"• An admin verifies your Mobile Money payment (usually ",
								PAYMENT_INFO.reviewWindow,
								")."
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"• Once approved, this page updates to ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground",
									children: "Approved"
								}),
								" and the reader unlocks."
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"• If the payment can't be found, the order is marked ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground",
									children: "Declined"
								}),
								" and you can order again."
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "• You can only read the book after your order is approved." })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: submit,
					disabled: busy,
					className: "mt-5 w-full rounded-full bg-gradient-teal px-5 py-3 text-sm font-semibold text-primary-foreground shadow-glow transition hover:opacity-90 disabled:opacity-50",
					children: busy ? "Submitting…" : "I've paid — submit my order"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-xs text-muted-foreground",
					children: "Questions about your order? Reply to the confirmation email or contact support with your reference."
				})
			]
		})]
	});
}
function Step({ n, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-teal-bright/40 bg-teal/10 text-xs font-semibold text-teal-bright",
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-medium text-foreground",
				children: title
			}), body]
		})]
	});
}
function Row({ label, value, onCopy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 rounded-lg border border-border/60 bg-background/40 px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[10px] uppercase tracking-widest text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "truncate text-sm text-foreground",
				children: value
			})]
		}), onCopy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: onCopy,
			className: "flex items-center gap-1 rounded-full border border-border px-2 py-1 text-[11px] text-muted-foreground hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-3 w-3" }), " Copy"]
		})]
	});
}
function BookPage() {
	const { isSuperAdmin, backendUrl } = useAuth();
	const [book, setBook] = (0, import_react.useState)({});
	const [access, setAccess] = (0, import_react.useState)(false);
	const book_id = Route.useParams().id;
	const { bookRequests } = useBooks();
	const fetchBook = async () => {
		const bookJson = await (await fetch(`${backendUrl}/book/${book_id}`)).json();
		console.log("BOOK", bookJson);
		setBook({
			...bookJson,
			"book_divisions": JSON.parse(bookJson["book_divisions"]),
			"stuff": []
		});
	};
	(0, import_react.useEffect)(() => {
		if (isSuperAdmin) {
			console.log("CHECK", isSuperAdmin);
			return setAccess(true);
		}
		if (!bookRequests.length) return;
		setAccess(bookRequests?.find((req) => req.book_id === book_id)?.status == "paid");
	}, [
		bookRequests,
		book,
		isSuperAdmin
	]);
	(0, import_react.useEffect)(() => {
		fetchBook();
	}, []);
	console.log("book", book);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			!book.book_name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: { height: "80vh" },
				className: "mt-16 text-center text-muted-foreground",
				children: "Loading book details …"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-6xl px-4 pt-10 pb-16 sm:px-6 sm:pt-12 sm:pb-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-12 md:grid-cols-[280px_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-2xl shadow-glow",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: book.book_cover_url,
								alt: book.book_name,
								className: "w-full"
							})
						}),
						access && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/read/$id",
							params: { id: book.book_id },
							className: "mt-6 flex w-full justify-center rounded-full bg-gradient-teal px-5 py-3 text-sm font-semibold text-primary-foreground shadow-glow",
							children: "Read"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PurchaseRequestButton, {
							bookId: book.book_id,
							adminId: book.admin_id,
							bookTitle: book.book_name,
							price: book.subscription_price,
							currency: book.currency || "R"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase tracking-widest text-teal-bright",
							children: book.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-3xl sm:text-4xl lg:text-5xl",
							children: book.book_name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-6 text-sm text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-display text-foreground",
									children: [
										book.currency || "R",
										" ",
										book.subscription_price
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: book.published_date }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [book.chapters, " chapters"] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl",
								children: "Chapters"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-4 divide-y divide-border/60 rounded-2xl border border-border/60 bg-surface",
								children: book.book_divisions && book.book_divisions.map((name, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center justify-between px-5 py-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: String(i + 1).padStart(2, "0")
										}),
										"  ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-3",
											children: name.title
										})
									] }), access && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/read/$id",
										params: { id: book.book_id },
										search: { chapter: name.start_page },
										className: "text-teal-bright hover:underline",
										children: "Read"
									})]
								}, i))
							})]
						})
					] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { BookPage as component };
