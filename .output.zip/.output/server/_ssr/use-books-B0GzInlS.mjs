import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useAuth, n as api } from "./use-auth-CIaruFYY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-books-B0GzInlS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Ctx = (0, import_react.createContext)({
	bookRequests: [],
	setBookRequests: () => {},
	readersBooks: [],
	setReadersBooks: () => {}
});
function BooksProvider({ children }) {
	const [bookRequests, setBookRequests] = (0, import_react.useState)([]);
	const [readersBooks, setReadersBooks] = (0, import_react.useState)([]);
	const { user, backendUrl } = useAuth();
	const base = backendUrl;
	const fetchBookRequests = async () => {
		try {
			const token = api.getToken();
			setBookRequests(await (await fetch(`${base}/readers_requests`, { "headers": { "Authorization": `Bearer ${token}` } })).json());
		} catch (e) {
			console.error("error fetching user book requests", e);
		}
	};
	const fetchReadersBooks = async () => {
		try {
			const token = api.getToken();
			setReadersBooks(await (await fetch(`${base}/library/me`, { "headers": { "Authorization": `Bearer ${token}` } })).json());
		} catch (e) {
			console.error("error fetching user book requests", e);
		}
	};
	(0, import_react.useEffect)(() => {
		fetchBookRequests();
		fetchReadersBooks();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ctx.Provider, {
		value: {
			bookRequests,
			setBookRequests,
			readersBooks,
			setReadersBooks
		},
		children
	});
}
var useBooks = () => (0, import_react.useContext)(Ctx);
//#endregion
export { useBooks as n, BooksProvider as t };
