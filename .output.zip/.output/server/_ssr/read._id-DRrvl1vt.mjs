import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/read._id-DRrvl1vt.js
var $$splitComponentImporter = () => import("./read._id-D4bHe2tW.mjs");
var $$splitErrorComponentImporter = () => import("./read._id-CJwAIDvc.mjs");
var $$splitNotFoundComponentImporter = () => import("./read._id-DqUvXpu6.mjs");
var Route = createFileRoute("/read/$id")({
	ssr: false,
	loader: ({ params }) => {
		return true;
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
