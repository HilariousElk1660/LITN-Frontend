import { A as notFound, m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as books } from "./books-B4AwiTZV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/author-DuBaVDf8.js
var $$splitComponentImporter = () => import("./author-C-pDLavO.mjs");
var $$splitErrorComponentImporter = () => import("./author-Ce8wO3dj.mjs");
var $$splitNotFoundComponentImporter = () => import("./author-BuV2WMqq.mjs");
var Route = createFileRoute("/author")({
	loader: ({ params }) => {
		const author = books.find((b) => b.authorId === params.id);
		if (!author) throw notFound();
		return {
			author,
			works: books.filter((b) => b.authorId === params.id)
		};
	},
	head: ({ loaderData }) => ({ meta: loaderData ? [{ title: `${loaderData.author.author} — LITN` }] : [] }),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
