import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book-card-80Ale8-j.js
var import_jsx_runtime = require_jsx_runtime();
function BookCard({ book }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/book/$id",
		params: { id: book.id },
		className: "group block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden rounded-xl border border-border/60 bg-surface shadow-card transition-transform duration-300 group-hover:-translate-y-1 group-hover:shadow-glow",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-[2/3] overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: book.cover,
						alt: book.title,
						loading: "lazy",
						className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute left-3 top-3 rounded-full bg-background/80 px-2 py-1 text-[10px] uppercase tracking-wider backdrop-blur",
					children: book.genre
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute right-3 top-3 rounded-full bg-gradient-teal px-2 py-1 text-[10px] font-semibold text-primary-foreground shadow-glow",
					children: [
						book.currency,
						" ",
						book.price
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 space-y-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "line-clamp-2 font-display text-base leading-tight",
				children: book.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					book.chapters,
					" chapters · ",
					book.status
				]
			})]
		})]
	});
}
//#endregion
export { BookCard as t };
