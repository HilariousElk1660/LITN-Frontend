import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useAuth, n as api } from "./use-auth-CIaruFYY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as CircleCheck, b as Crown, k as BookOpen, l as Shield, w as Circle } from "../_libs/lucide-react.mjs";
import { t as SiteHeader } from "./site-header-CgAShUuv.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-B1h6DJwX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Profile() {
	const { user, isAdmin, isSuperAdmin, loading: authLoading, refresh } = useAuth();
	const [fullname, setFullname] = (0, import_react.useState)(user?.fullname ?? "");
	const [email, setEmail] = (0, import_react.useState)(user?.email ?? "");
	const [savingProfile, setSavingProfile] = (0, import_react.useState)(false);
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [savingPassword, setSavingPassword] = (0, import_react.useState)(false);
	const [library, setLibrary] = (0, import_react.useState)(null);
	const [libraryLoading, setLibraryLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		api.get("/library/me").then(setLibrary).catch((err) => toast.error(err.message)).finally(() => setLibraryLoading(false));
	}, [user]);
	const initials = (user?.fullname || user?.email || "?").split(" ").map((part) => part[0]).slice(0, 2).join("").toUpperCase();
	const onSaveProfile = async (e) => {
		e.preventDefault();
		setSavingProfile(true);
		try {
			const auth = await api.patch("/auth/profile", {
				fullname,
				email
			});
			api.saveSession(auth);
			refresh();
			toast.success("Profile updated.");
		} catch (err) {
			toast.error(err.message);
		} finally {
			setSavingProfile(false);
		}
	};
	const onChangePassword = async (e) => {
		e.preventDefault();
		setSavingPassword(true);
		try {
			await api.patch("/auth/password", {
				current_password: currentPassword,
				password: newPassword
			});
			toast.success("Password changed.");
			setCurrentPassword("");
			setNewPassword("");
		} catch (err) {
			toast.error(err.message);
		} finally {
			setSavingPassword(false);
		}
	};
	if (authLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {})
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-md px-4 py-16 text-center sm:px-6 sm:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl sm:text-4xl",
				children: "Sign in required."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: "You need an account to view this page."
			})]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl px-4 py-16 sm:px-6 sm:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-start gap-4 sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-16 w-16 items-center justify-center rounded-full bg-gradient-teal text-lg font-semibold text-primary-foreground shadow-glow",
						children: initials
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl sm:text-4xl",
						children: "Your profile."
					}), isSuperAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 inline-flex items-center gap-1 rounded-full border border-teal-bright/40 bg-teal/10 px-3 py-1 text-[10px] font-medium uppercase tracking-widest text-teal-bright",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-3 w-3" }), " Super Admin"]
					}) : isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 inline-flex items-center gap-1 rounded-full border border-teal-bright/40 bg-teal/10 px-3 py-1 text-[10px] font-medium uppercase tracking-widest text-teal-bright",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-3 w-3" }), " Admin"]
					}) : null] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-muted-foreground",
					children: "Manage your account details and password."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-10 space-y-4",
					onSubmit: onSaveProfile,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							placeholder: "Full name",
							required: true,
							value: fullname,
							onChange: (e) => setFullname(e.target.value),
							className: "w-full rounded-full border border-border bg-surface px-5 py-3 text-sm outline-none focus:border-primary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							placeholder: "Email",
							required: true,
							value: email,
							onChange: (e) => setEmail(e.target.value),
							className: "w-full rounded-full border border-border bg-surface px-5 py-3 text-sm outline-none focus:border-primary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: savingProfile,
							className: "w-full rounded-full bg-gradient-teal px-5 py-3 text-sm font-semibold text-primary-foreground shadow-glow disabled:opacity-60",
							children: savingProfile ? "Saving…" : "Save changes"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-12 border-t border-border/60 pt-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Change password."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-6 space-y-4",
						onSubmit: onChangePassword,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								placeholder: "Current password",
								required: true,
								autoComplete: "current-password",
								value: currentPassword,
								onChange: (e) => setCurrentPassword(e.target.value),
								className: "w-full rounded-full border border-border bg-surface px-5 py-3 text-sm outline-none focus:border-primary"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								placeholder: "New password (min 6 chars)",
								minLength: 6,
								required: true,
								autoComplete: "new-password",
								value: newPassword,
								onChange: (e) => setNewPassword(e.target.value),
								className: "w-full rounded-full border border-border bg-surface px-5 py-3 text-sm outline-none focus:border-primary"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: savingPassword,
								className: "w-full rounded-full border border-border px-5 py-3 text-sm font-semibold text-foreground transition hover:border-primary disabled:opacity-60",
								children: savingPassword ? "Updating…" : "Update password"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-12 border-t border-border/60 pt-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Reading roadmap."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted-foreground",
							children: "Where you've left off across every book."
						}),
						libraryLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm text-muted-foreground",
							children: "Loading your library…"
						}) : !library || library.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm text-muted-foreground",
							children: "You haven't started any books yet."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-6 space-y-6",
							children: library.map((entry) => {
								const pct = entry.percentage_completed ?? 0;
								const isDone = entry.progress === "done";
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/read/$id",
									params: { id: entry.book_id },
									className: "block rounded-2xl border border-border/60 bg-surface p-5 transition hover:border-primary/60",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start gap-3",
												children: [entry.book_cover_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: entry.book_cover_url,
													alt: "",
													className: "h-14 w-10 shrink-0 rounded object-cover"
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex h-14 w-10 shrink-0 items-center justify-center rounded bg-border/60",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "h-4 w-4 text-muted-foreground" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [isDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 shrink-0 text-teal-bright" }) : entry.progress === "in_progress" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "h-4 w-4 shrink-0 text-teal-bright" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-4 w-4 shrink-0 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "font-medium",
														children: entry.book_name
													})]
												}), entry.author_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-sm text-muted-foreground",
													children: entry.author_name
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "whitespace-nowrap text-sm font-medium text-teal-bright",
												children: [pct, "%"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-4 h-2 w-full overflow-hidden rounded-full bg-border/60",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full rounded-full bg-gradient-teal transition-all",
												style: { width: `${Math.min(100, Math.max(0, pct))}%` }
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
													"Page ",
													entry.current_page,
													" of ",
													entry.total_pages
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
													"Chapter ",
													entry.current_chapter_index + 1,
													" of ",
													entry.total_chapters
												] }),
												entry.page_stopped_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Stopped at: ", entry.page_stopped_at] }),
												entry.last_opened && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Last opened ", new Date(entry.last_opened).toLocaleDateString()] })
											]
										})
									]
								}) }, entry.reader_book_id);
							})
						})
					]
				})
			]
		})]
	});
}
//#endregion
export { Profile as component };
